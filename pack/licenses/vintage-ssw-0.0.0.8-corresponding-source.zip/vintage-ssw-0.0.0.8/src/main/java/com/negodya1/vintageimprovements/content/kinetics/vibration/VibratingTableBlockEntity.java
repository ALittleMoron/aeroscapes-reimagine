package com.negodya1.vintageimprovements.content.kinetics.vibration;

import com.negodya1.vintageimprovements.VintageImprovements;
import com.negodya1.vintageimprovements.VintageRecipes;
import com.negodya1.vintageimprovements.VintageRecipesList;
import com.negodya1.vintageimprovements.content.kinetics.helve_hammer.HelveBlock;
import com.negodya1.vintageimprovements.foundation.advancement.VintageAdvancementBehaviour;
import com.negodya1.vintageimprovements.foundation.advancement.VintageAdvancements;
import com.negodya1.vintageimprovements.infrastructure.config.VintageConfig;
import com.simibubi.create.AllSoundEvents;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;
import com.simibubi.create.content.kinetics.belt.behaviour.DirectBeltInputBehaviour;
import com.simibubi.create.content.processing.sequenced.SequencedAssemblyRecipe;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.item.ItemHelper;
import com.simibubi.create.foundation.item.SmartInventory;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.MethodsReturnNonnullByDefault;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.Clearable;
import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import net.neoforged.neoforge.items.IItemHandler;
import net.neoforged.neoforge.items.ItemHandlerHelper;
import net.neoforged.neoforge.items.ItemStackHandler;
import net.neoforged.neoforge.items.wrapper.CombinedInvWrapper;
import net.neoforged.neoforge.items.wrapper.RecipeWrapper;

import javax.annotation.ParametersAreNonnullByDefault;
import java.util.*;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class VibratingTableBlockEntity extends KineticBlockEntity implements Clearable {
	public SmartInventory inputInv;
	public SmartInventory outputInv;
	public IItemHandler capability;
	public int timer;
	private VibratingRecipe lastRecipe;
	private ItemStack playEvent;
	boolean lastRecipeIsAssembly;
	VintageAdvancementBehaviour advancementBehaviour;

	public static final TagKey<Item> leavesTag = ItemTags.create(ResourceLocation.fromNamespaceAndPath("minecraft", "leaves"));

	public VibratingTableBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
		super(type, pos, state);

		inputInv = new SmartInventory(1, this);
		outputInv = new SmartInventory(9, this);
		capability = new VibratingTableInventoryHandler();
		playEvent = ItemStack.EMPTY;
	}

	public float getRenderedHeadOffset(float partialTicks) {
		return partialTicks * 3 / 16f;
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		behaviours.add(new DirectBeltInputBehaviour(this));
		super.addBehaviours(behaviours);
		advancementBehaviour = new VintageAdvancementBehaviour(this);
		behaviours.add(advancementBehaviour);
	}

	@Override
	public void write(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
		compound.putInt("Timer", timer);
		compound.put("InputInventory", inputInv.serializeNBT(registries));
		compound.put("OutputInventory", outputInv.serializeNBT(registries));
		compound.putBoolean("LastRecipeIsAssembly", lastRecipeIsAssembly);
		super.write(compound, registries, clientPacket);

		if (!clientPacket || playEvent.isEmpty())
			return;
		compound.put("PlayEvent", playEvent.saveOptional(registries));
		playEvent = ItemStack.EMPTY;
	}

	@Override
	protected void read(CompoundTag compound, HolderLookup.Provider registries, boolean clientPacket) {
		super.read(compound, registries, clientPacket);
		timer = compound.getInt("Timer");
		inputInv.deserializeNBT(registries, compound.getCompound("InputInventory"));
		outputInv.deserializeNBT(registries, compound.getCompound("OutputInventory"));
		lastRecipeIsAssembly = compound.getBoolean("LastRecipeIsAssembly");
		if (compound.contains("PlayEvent"))
			playEvent = ItemStack.parseOptional(registries, compound.getCompound("PlayEvent"));
	}

	@Override
	protected AABB createRenderBoundingBox() {
		return new AABB(worldPosition).inflate(.125f);
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public void tickAudio() {
		super.tickAudio();
		if (getSpeed() == 0)
			return;

		if (!playEvent.isEmpty()) {
			playEvent = ItemStack.EMPTY;

			AllSoundEvents.SANDING_SHORT.playAt(level, worldPosition, 3, 1, true);
		}
	}

	public void spawnParticles() {
		if (!haveRecipe()) return;

		ItemStack stackInSlot = inputInv.getStackInSlot(0);
		if (stackInSlot.isEmpty())
			return;

		ItemParticleOption data = new ItemParticleOption(ParticleTypes.ITEM, stackInSlot);
		float angle = level.random.nextFloat() * 360;
		Vec3 offset = new Vec3(0, 0, 0.5f);
		offset = VecHelper.rotate(offset, angle, Direction.Axis.Y);
		Vec3 target = VecHelper.rotate(offset, getSpeed() > 0 ? 25 : -25, Direction.Axis.Y);

		Vec3 center = offset.add(VecHelper.getCenterOf(worldPosition));
		target = VecHelper.offsetRandomly(target.subtract(offset), level.random, 1 / 128f);
		level.addParticle(data, center.x, center.y + 8 / 16f + getRenderedHeadOffset(Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false)), center.z, target.x, target.y, target.z);
	}

	@Override
	public void tick() {
		super.tick();

		if (getSpeed() == 0)
			return;
		for (int i = 0; i < outputInv.getSlots(); i++)
			if (outputInv.getStackInSlot(i)
					.getCount() == outputInv.getSlotLimit(i))
				return;

		if (timer > 0) {
			timer -= getProcessingSpeed();

			if (level.isClientSide) {
				spawnParticles();
				return;
			}
			if (timer <= 0)
				process();
			return;
		}

		if (inputInv.getStackInSlot(0)
				.isEmpty())
			return;

		RecipeWrapper inventoryIn = new RecipeWrapper(inputInv);
		if (lastRecipe == null || (!lastRecipe.matches(inventoryIn, level))) {
			Optional<RecipeHolder<VibratingRecipe>> assemblyRecipe = SequencedAssemblyRecipe.getRecipe(level, inventoryIn,
					VintageRecipes.VIBRATING.getType(), VibratingRecipe.class);
			if (assemblyRecipe.isPresent()) {
				lastRecipe = assemblyRecipe.get().value();
				timer = lastRecipe.getProcessingDuration();
				if (timer == 0) timer = 100;
				lastRecipeIsAssembly = true;

				sendData();
				return;
			}

			lastRecipeIsAssembly = false;

			Optional<RecipeHolder<VibratingRecipe>> recipe = VintageRecipes.VIBRATING.find(inventoryIn, level);
			if (!recipe.isPresent()) {
				timer = 100;
				sendData();
			} else {
				lastRecipe = recipe.get().value();
				timer = lastRecipe.getProcessingDuration();
				sendData();
			}
			return;
		}

		timer = lastRecipe.getProcessingDuration();
		if (timer == 0) timer = 100;
		sendData();
	}

	@Override
	public void invalidate() {
		super.invalidate();
	}

	@Override
	public void destroy() {
		super.destroy();
		ItemHelper.dropContents(level, worldPosition, inputInv);
		ItemHelper.dropContents(level, worldPosition, outputInv);
	}

	@Override
	public void clearContent() {
		inputInv.clearContent();
		outputInv.clearContent();
	}

	private ItemStack haveRecipeCachedInput = ItemStack.EMPTY;
	private boolean haveRecipeCachedFastEnough;
	private Object haveRecipeCachedRecipeManager;
	private boolean haveRecipeCachedResult;

	public boolean haveRecipe() {
		// Called every frame by the renderer (renderTable + renderItems) and every
		// client tick by spawnParticles, so the full recipe lookup in canProcess()
		// must be cached. The result only depends on the input stack, whether the
		// speed threshold is met, and the current recipe manager (which is swapped
		// on datapack reload).
		ItemStack stack = inputInv.getStackInSlot(0);
		boolean fastEnough = Mth.abs(getSpeed()) >= IRotate.SpeedLevel.FAST.getSpeedValue();
		Object recipeManager = level == null ? null : level.getRecipeManager();
		if (fastEnough == haveRecipeCachedFastEnough && recipeManager == haveRecipeCachedRecipeManager
				&& ItemStack.isSameItemSameComponents(haveRecipeCachedInput, stack))
			return haveRecipeCachedResult;

		haveRecipeCachedFastEnough = fastEnough;
		haveRecipeCachedRecipeManager = recipeManager;
		haveRecipeCachedInput = stack.copy();
		haveRecipeCachedResult = canProcess(stack);
		return haveRecipeCachedResult;
	}

	private boolean canProcess(ItemStack stack) {
		if (Mth.abs(getSpeed()) < IRotate.SpeedLevel.FAST.getSpeedValue()) return false;

		Optional<RecipeHolder<VibratingRecipe>> assemblyRecipe = SequencedAssemblyRecipe.getRecipe(level, stack,
				VintageRecipes.VIBRATING.getType(), VibratingRecipe.class);
		if (assemblyRecipe.isPresent()) return true;

		ItemStackHandler tester = new ItemStackHandler(1);
		tester.setStackInSlot(0, stack);
		RecipeWrapper inventoryIn = new RecipeWrapper(tester);

		if (lastRecipe != null && lastRecipe.matches(inventoryIn, level))
			return true;
		if (VintageRecipes.VIBRATING.find(inventoryIn, level)
				.isPresent()) return true;

		if (VintageConfig.server().recipes.allowVibratingLeaves.get() && VintageRecipes.LEAVES_VIBRATING.find(inventoryIn, level)
				.isPresent()) return true;

		return VintageConfig.server().recipes.allowUnpackingOnVibratingTable.get()
				&& VintageRecipesList.findUnpacking(stack).isPresent();
	}

	private void process() {
		RecipeWrapper inventoryIn = new RecipeWrapper(inputInv);

		// Sequenced assembly binds the next result to a shared recipe instance.
		// Refresh it at completion so another lookup cannot overwrite that result.
		if (lastRecipeIsAssembly)
			lastRecipe = null;

		if (lastRecipe == null || !lastRecipe.matches(inventoryIn, level)) {
			boolean found = false;

			Optional<RecipeHolder<VibratingRecipe>> assemblyRecipe = SequencedAssemblyRecipe.getRecipe(level, inventoryIn,
					VintageRecipes.VIBRATING.getType(), VibratingRecipe.class);
			if (assemblyRecipe.isPresent()) {
				lastRecipe = assemblyRecipe.get().value();
				lastRecipeIsAssembly = true;
				found = true;
			}

			if (!found) {
				lastRecipeIsAssembly = false;
				Optional<RecipeHolder<VibratingRecipe>> recipe = VintageRecipes.VIBRATING.find(inventoryIn, level);
				if (recipe.isPresent()) {
					lastRecipe = recipe.get().value();
					found = true;
				}
			}

			if (!found && VintageConfig.server().recipes.allowUnpackingOnVibratingTable.get()) {
				Optional<CraftingRecipe> unpackingRecipe =
						VintageRecipesList.findUnpacking(inputInv.getStackInSlot(0));
				if (unpackingRecipe.isPresent()) {
					ItemStack stackInSlot = inputInv.getStackInSlot(0);
					stackInSlot.shrink(1);
					inputInv.setStackInSlot(0, stackInSlot);

					ItemStack result = unpackingRecipe.get().getResultItem(level.registryAccess()).copy();
					ItemHandlerHelper.insertItemStacked(outputInv, result, false);
					advancementBehaviour.awardVintageAdvancement(VintageAdvancements.USE_VIBRATION_TABLE);

					sendData();
					setChanged();

					return;
				}
			}

			if (!found && VintageConfig.server().recipes.allowVibratingLeaves.get() && inputInv.getStackInSlot(0).is(leavesTag)) {
				ItemStack stackInSlot = inputInv.getStackInSlot(0);

				if (stackInSlot.getItem() instanceof BlockItem) {
					Block leaves = Block.byItem(stackInSlot.getItem());

					ItemStack hoe = Items.DIAMOND_HOE.getDefaultInstance();
					hoe.enchant(level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(Enchantments.FORTUNE), 3);

					List<ItemStack> list = Block.getDrops(leaves.defaultBlockState(), (ServerLevel) level, this.worldPosition, null, null, hoe.copy());

					for (ItemStack result : list) {
						ItemHandlerHelper.insertItemStacked(outputInv, result, false);
					}
				}

				stackInSlot.shrink(1);
				inputInv.setStackInSlot(0, stackInSlot);
				advancementBehaviour.awardVintageAdvancement(VintageAdvancements.USE_VIBRATION_TABLE);

				sendData();
				setChanged();

				return;
			}

			if (!found) return;
		}

		if (lastRecipeIsAssembly) {
			VibratingRecipe.apply(this, lastRecipe);
			lastRecipe = null;
		}
		else {
			ItemStack stackInSlot = inputInv.getStackInSlot(0);
			stackInSlot.shrink(1);
			inputInv.setStackInSlot(0, stackInSlot);

			lastRecipe.rollResults(level.random)
					.forEach(stack -> ItemHandlerHelper.insertItemStacked(outputInv, stack, false));
		}
		advancementBehaviour.awardVintageAdvancement(VintageAdvancements.USE_VIBRATION_TABLE);

		sendData();
		setChanged();
	}

	public boolean acceptOutputs(List<ItemStack> outputItems, boolean simulate) {
		outputInv.allowInsertion();
		boolean acceptOutputsInner = acceptOutputsInner(outputItems, simulate);
		outputInv.forbidInsertion();
		return acceptOutputsInner;
	}

	private boolean acceptOutputsInner(List<ItemStack> outputItems, boolean simulate) {
		BlockState blockState = getBlockState();
		if (!(blockState.getBlock() instanceof VibratingTableBlock))
			return false;

		IItemHandler targetInv = outputInv;

		if (targetInv == null && !outputItems.isEmpty())
			return false;
		if (!acceptItemOutputsIntoHelve(outputItems, simulate, targetInv))
			return false;

		return true;
	}

	private boolean acceptItemOutputsIntoHelve(List<ItemStack> outputItems, boolean simulate, IItemHandler targetInv) {
		for (ItemStack itemStack : outputItems) {
			if (!ItemHandlerHelper.insertItemStacked(targetInv, itemStack.copy(), simulate)
					.isEmpty())
				return false;
		}
		return true;
	}

	public int getProcessingSpeed() {
		return Mth.clamp((int) Math.abs(getSpeed() / 16f), 1, 512);
	}

	private class VibratingTableInventoryHandler extends CombinedInvWrapper {

		public VibratingTableInventoryHandler() {
			super(inputInv, outputInv);
		}

		@Override
		public boolean isItemValid(int slot, ItemStack stack) {
			if (outputInv == getHandlerFromIndex(getIndexForSlot(slot)))
				return false;
			return canProcess(stack) && super.isItemValid(slot, stack);
		}

		@Override
		public ItemStack insertItem(int slot, ItemStack stack, boolean simulate) {
			if (outputInv == getHandlerFromIndex(getIndexForSlot(slot)))
				return stack;
			if (!isItemValid(slot, stack))
				return stack;
			return super.insertItem(slot, stack, simulate);
		}

		@Override
		public ItemStack extractItem(int slot, int amount, boolean simulate) {
			if (inputInv == getHandlerFromIndex(getIndexForSlot(slot)))
				return ItemStack.EMPTY;
			return super.extractItem(slot, amount, simulate);
		}

	}

}

