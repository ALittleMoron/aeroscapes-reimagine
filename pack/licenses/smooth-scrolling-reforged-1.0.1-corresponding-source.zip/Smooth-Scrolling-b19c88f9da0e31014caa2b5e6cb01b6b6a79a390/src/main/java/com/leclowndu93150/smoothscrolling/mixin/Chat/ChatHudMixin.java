package com.leclowndu93150.smoothscrolling.mixin.Chat;

import java.util.List;

import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import org.spongepowered.asm.mixin.injection.At;

import net.minecraft.client.GuiMessage;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.util.FastColor;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.phys.Vec2;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;

@Mixin(value = ChatComponent.class, priority = 1001) // i want mods to modify the Chat position before, so i get to know where they put it
public class ChatHudMixin {

    @Shadow private int chatScrollbarPos;
    @Final @Shadow private List<GuiMessage.Line> trimmedMessages;

    @Unique private float scrollOffset;
    @Unique private float maskHeightBuffer;
    @Unique private boolean refreshing = false;
    @Unique private int scrollValBefore;
    @Unique private int savedCurrentTick;
    @Unique private Vec2 mtc = new Vec2(0, 0); // account for matrix translate at the beginning of render
    @Unique private int shownLineCount;

    @Inject(method = "render", at = @At("HEAD"))
    private void renderH(GuiGraphics context, int currentTick, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
        if (Config.CHAT_SMOOTHNESS.get() == 0) return;
        savedCurrentTick = currentTick;

        scrollOffset = (float) (scrollOffset * Math.pow(Config.CHAT_SMOOTHNESS.get(), SmoothSc.getLastFrameDuration()));

        scrollValBefore = chatScrollbarPos;
        chatScrollbarPos -= getChatScrollOffset() / getLineHeight();
        if (chatScrollbarPos < 0) chatScrollbarPos = 0;
    }

    @ModifyArgs(method = "render", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V", ordinal = 0))
    private void matrixTranslateCorrector(Args args) {
        int x = (int) (float) args.get(0) - 4;
        int y = (int) (float) args.get(1);

        var newY = (float) ((mtc.y - y) * Math.pow(Config.CHAT_OPENING_SMOOTHNESS.get(), SmoothSc.getLastFrameDuration()) + y);

        args.set(1, (float) Math.round(newY));
        mtc = new Vec2(x, newY);
    }

    @ModifyVariable(method = "render", at = @At("STORE"), ordinal = 7)
    private int mask(int m, @Local(argsOnly = true) GuiGraphics context, @Local float f) { // m - the y position of the Chat
        if ((Config.CHAT_SMOOTHNESS.get() == 0 && Config.CHAT_OPENING_SMOOTHNESS.get() == 0) || isChatHidden()) return (m);

        var shownLineCount = 0;
        //SmoothSc.print("1: "+trimmedMessages.size());
        for(int r = 0; r + chatScrollbarPos < trimmedMessages.size() && r < getLinesPerPage(); r++) {
            //SmoothSc.print("2: "+(savedCurrentTick - trimmedMessages.get(r).addedTime()));
            if (savedCurrentTick - trimmedMessages.get(r).addedTime() < 200 || isChatFocused()) shownLineCount++;
        }
        // var targetHeight = getVisibleLineCount() * getLineHeight();
        var targetHeight = shownLineCount * getLineHeight();

        // mask doesn't really match the smooth scrolling with the first few messages
        // i really don't know the root cause currently
        // cause: targetHeight matches the interpolated scroll value for some reason
        //     when the shownlinecount is equal to the size of visible messages
        //     so the mask falls behind sometimes
        // not working great workaround:
        // if (shownLineCount == trimmedMessages.size()) maskHeightBuffer = targetHeight;
        // else {
        maskHeightBuffer = (float) ((maskHeightBuffer - targetHeight) * Math.pow(Config.CHAT_OPENING_SMOOTHNESS.get(), SmoothSc.getLastFrameDuration()) + targetHeight);

        var masktop = m - Math.round(maskHeightBuffer);
        var maskbottom = m;

        // this makes underlined text and such correct again
        if (getChatScrollOffset() == 0 && Math.round(maskHeightBuffer) != 0) {
            if (Math.round(maskHeightBuffer) == targetHeight) {
                maskbottom += 2;
                masktop -= 2;
            } else {
                maskbottom += 2;
            }
        }
		var mtpos = SmoothSc.getMatrixTranslate(context);
        //mtpos = new Vector3f(0,0,0);

        SmoothSc.scissorScaleFactor = SmoothSc.mc.getWindow().getGuiScale() * f;
        context.enableScissor((int) mtpos.x - 20, (int) mtpos.y + masktop, (int) mtpos.x + context.guiWidth(), (int) mtpos.y + maskbottom);
        SmoothSc.scissorScaleFactor = 0;

        return (m);
    }

    @ModifyVariable(method = "render", at = @At(value = "STORE"), ordinal = 14)
    private int opacity(int t) {
        if (Config.CHAT_OPENING_SMOOTHNESS.get() == 0) return (t);
        return (0);
    }

    @ModifyVariable(method = "render", at = @At(value = "STORE"), ordinal = 18)
    private int changePosY(int y) {
        if (Config.CHAT_SMOOTHNESS.get() == 0) return (y);
        return (y - getChatDrawOffset());
    }

    @ModifyVariable(method = "render", at = @At("STORE"))
    private long demask(long a, @Local(argsOnly = true) GuiGraphics context) { // after the cycle
        if ((Config.CHAT_SMOOTHNESS.get() == 0 && Config.CHAT_OPENING_SMOOTHNESS.get() == 0) || this.isChatHidden()) return (a);
        if (Config.ENABLE_MASK_DEBUG.get()) context.fill(-10000, -10000, 10000, 10000, FastColor.ARGB32.color(50, 255, 0, 255));
        context.disableScissor();
        return (a);
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void renderT(GuiGraphics context, int currentTick, int mouseX, int mouseY, boolean focused, CallbackInfo ci) {
        if (Config.CHAT_SMOOTHNESS.get() == 0) return;
        chatScrollbarPos = scrollValBefore;
    }

    @ModifyVariable(method = "addMessageToDisplayQueue", at = @At("STORE"), ordinal = 0)
    private List<FormattedCharSequence> onNewMessage(List<FormattedCharSequence> ot) {
        if (refreshing) return (ot);
        scrollOffset -= ot.size() * getLineHeight();
        return (ot);
    }

    @Inject(method = "scrollChat", at = @At("HEAD"))
    private void scrollH(int scroll, CallbackInfo ci) {
        scrollValBefore = chatScrollbarPos;
    }

    @Inject(method = "scrollChat", at = @At("TAIL"))
    private void scrollT(int scroll, CallbackInfo ci) {
        scrollOffset += (chatScrollbarPos - scrollValBefore) * getLineHeight();
    }

    @Inject(method = "resetChatScroll", at = @At("HEAD"))
    private void scrollResetH(CallbackInfo ci) {
        scrollValBefore = chatScrollbarPos;
    }

    @Inject(method = "resetChatScroll", at = @At("TAIL"))
    private void scrollResetT(CallbackInfo ci) {
        scrollOffset += (chatScrollbarPos - scrollValBefore) * getLineHeight();
    }

    @ModifyVariable(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/ChatComponent;getLineHeight()I"), ordinal = 3)
    private int addLinesAbove(int i) {
        if (Config.CHAT_SMOOTHNESS.get() == 0 && Config.CHAT_OPENING_SMOOTHNESS.get() == 0) return (i);
        return ((int) Math.ceil(Math.round(maskHeightBuffer) / (float) getLineHeight()) + (getChatScrollOffset() < 0 ? 1 : 0));
    }

    @ModifyVariable(method = "render", at = @At(value = "STORE"), ordinal = 12)
    private int addLinesUnder(int r) {
        if (chatScrollbarPos == 0 || Config.CHAT_SMOOTHNESS.get() == 0 || getChatScrollOffset() <= 0) return (r);
        return (r - 1);
    }

    @Inject(method = "refreshTrimmedMessages", at = @At("HEAD"))
    private void refreshH(CallbackInfo ci) {refreshing = true;}

    @Inject(method = "refreshTrimmedMessages", at = @At("TAIL"))
    private void refreshT(CallbackInfo ci) {refreshing = false;}

    @Shadow
    private int getLineHeight() {return (0);}

    @Shadow
    public double getScale() {return (0);}

    @Shadow
    public int getWidth() {return (0);}
    
    @Shadow
    public int getLinesPerPage() {return (0);}

    @Shadow
    private boolean isChatHidden() {return (false);}

    @Shadow
    public boolean isChatFocused() {return (false);}

    @Unique
    private int getChatDrawOffset() {
        return Math.round(scrollOffset) - (Math.round(scrollOffset) / getLineHeight() * getLineHeight());
    }

    @Unique
    private int getChatScrollOffset() {
        return Math.round(scrollOffset);
    }
}
