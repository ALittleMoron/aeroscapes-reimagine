package com.leclowndu93150.smoothscrolling.mixin;

import com.leclowndu93150.smoothscrolling.SmoothSc;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractScrollWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractScrollWidget.class)
public class ScrollableWidgetMixin { // DISABLED

    @Shadow private double scrollAmount;
    @Unique private double predScrollY;
    @Unique private double targetScrollY;

    @Inject(method = "setScrollAmount(D)V", at = @At("HEAD"))
    private void SetScrollYH(double s, CallbackInfo ci) {
        predScrollY = scrollAmount;
    }

    @Inject(method = "setScrollAmount(D)V", at = @At("TAIL"))
    private void SetScrollYT(double s, CallbackInfo ci) {
        targetScrollY = scrollAmount;
        scrollAmount = predScrollY;
    }

    @Inject(method = "renderScrollBar", at = @At("HEAD"))
    private void drawScrollbarH(GuiGraphics context, CallbackInfo ci) {
        scrollAmount = (scrollAmount - targetScrollY) / Math.pow(2, SmoothSc.getLastFrameDuration()) + targetScrollY;
        if (scrollAmount < targetScrollY + 0.1 && scrollAmount > targetScrollY - 0.1)
            scrollAmount = targetScrollY;
    }
}
