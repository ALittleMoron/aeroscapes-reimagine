package com.leclowndu93150.smoothscrolling.mixin.creative_screen;

import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen.ItemPickerMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;

@Mixin(value = ItemPickerMenu.class, priority = 1001)
public class CreativeScreenHandlerMixin {

    @ModifyVariable(method = "scrollTo", at = @At("STORE"), ordinal = 0)
    private int scrollItems(int row) {
        if (Config.CREATIVE_SCREEN_SMOOTHNESS.get() == 0) return (row);
        SmoothSc.creativeScreenItemCount = 0;
        if (!SmoothSc.creativeScreenScrollMixin) return (row);
        
        SmoothSc.creativeScreenScrollOffset += 18 * (row - SmoothSc.creativeScreenPrevRow);
        SmoothSc.creativeScreenPrevRow = row;
        return (row);
    }

    @Inject(method = "scrollTo", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/SimpleContainer;setItem(ILnet/minecraft/world/item/ItemStack;)V"))
    private void itemCount(CallbackInfo ci) {
        SmoothSc.creativeScreenItemCount += 1;
    }
}
