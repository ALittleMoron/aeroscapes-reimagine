package com.leclowndu93150.smoothscrolling.mixin;

import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import com.leclowndu93150.smoothscrolling.SmoothSc;

@Mixin(GuiGraphics.class)
public class DrawContextMixin {
    @ModifyVariable(method = "applyScissor", at = @At(value = "STORE"), ordinal = 0)
    private double changeScissorScaleFactor(double d) {
        if (SmoothSc.scissorScaleFactor == 0) return d;
        return SmoothSc.scissorScaleFactor;
    }
}
