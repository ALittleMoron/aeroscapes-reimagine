package com.leclowndu93150.smoothscrolling;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen.ItemPickerMenu;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.AbstractContainerMenu;
import org.joml.Vector3f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.leclowndu93150.smoothscrolling.compat.CondensedInventoryCompat;

public class SmoothSc {
    public static final Logger LOGGER = LoggerFactory.getLogger("Smooth Scrolling");
    public static final Minecraft mc = Minecraft.getInstance();

    public static double scissorScaleFactor;

    public static float creativeScreenScrollOffset = 0;
    public static int creativeScreenItemCount = 0;
    public static ItemPickerMenu creativeSH;
    public static boolean creativeScreenScrollMixin = true;
    public static int creativeScreenPrevRow = 0;

    public static int hotbarRollover = 0;

    public static void print(Object... s) {
        joinPrint(", ", s);
    }

    public static void joinPrint(String join, Object... s) {
        String a = "";
        for (Object object : s) {
            a += object + join;
        }
        LOGGER.info(a);
    }

    public static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }

    public static float getLastFrameDuration() {
        return mc.getTimer().getGameTimeDeltaTicks();
    }

    public static void debugTextDraw(GuiGraphics context, Object s, int x, int y) {
        context.drawString(mc.font, s + "", x, y, FastColor.ARGB32.color(255, 0, 255, 255), true);
    }

    public static Container getDelegatingInventory(AbstractContainerMenu handler) {
        return SmoothScrolling.isCondensedInventoryLoaded
                ? CondensedInventoryCompat.of(handler)
                : DelegatingInventory.itemStackBased(creativeSH.items::get);
    }

    public static int getCreativeDrawOffset() {
        return Math.round(SmoothSc.creativeScreenScrollOffset) - Math.round(SmoothSc.creativeScreenScrollOffset) / 18 * 18;
    }

    public static int getCreativeScrollOffset() {
        return Math.round(SmoothSc.creativeScreenScrollOffset);
    }

    public static void drawHotbarRolloverMirror(GuiGraphics context, ResourceLocation texture, int x, int hotbarWidth, int offset, int y, int width, int height) {
        context.blitSprite(texture, x + hotbarWidth + offset, y, width, height);
    }

    public static Vector3f getMatrixTranslate(GuiGraphics context) {
        return context.pose().last().pose().getTranslation(new Vector3f(0, 0, 0));
    }
}
