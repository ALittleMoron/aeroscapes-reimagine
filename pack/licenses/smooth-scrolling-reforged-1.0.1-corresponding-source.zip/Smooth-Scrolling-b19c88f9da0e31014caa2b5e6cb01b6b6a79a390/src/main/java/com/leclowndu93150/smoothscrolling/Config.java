package com.leclowndu93150.smoothscrolling;

import net.neoforged.neoforge.common.ModConfigSpec;

public class Config {
    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();
    
    public static final ModConfigSpec.DoubleValue HOTBAR_SMOOTHNESS;
    public static final ModConfigSpec.BooleanValue HOTBAR_ROLLOVER;
    public static final ModConfigSpec.DoubleValue CHAT_SMOOTHNESS;
    public static final ModConfigSpec.DoubleValue CHAT_OPENING_SMOOTHNESS;
    public static final ModConfigSpec.DoubleValue CREATIVE_SCREEN_SMOOTHNESS;
    public static final ModConfigSpec.DoubleValue ENTRY_LIST_SMOOTHNESS;
    public static final ModConfigSpec.DoubleValue ENTRY_LIST_SPEED;
    public static final ModConfigSpec.BooleanValue ENABLE_MASK_DEBUG;
    
    static {
        BUILDER.comment("Safe values for settings are 0 - 1 (inclusive).",
                "0 means animation off (no smoothness) and bigger values mean slower animation speed (high smoothness).",
                "Press F3+T in a world to update the config.");
        
        BUILDER.push("Hotbar");
        HOTBAR_SMOOTHNESS = BUILDER
                .comment("Hotbar scroll smoothness. 0 = Off, 1 = Maximum smoothness")
                .defineInRange("smoothness", 0.2, 0.0, 1.0);
        HOTBAR_ROLLOVER = BUILDER
                .comment("Enable Hotbar rollover when scrolling")
                .define("rollover", true);
        BUILDER.pop();
        
        BUILDER.push("Chat");
        CHAT_SMOOTHNESS = BUILDER
                .comment("Chat scroll smoothness. 0 = Off, 1 = Maximum smoothness")
                .defineInRange("smoothness", 0.5, 0.0, 1.0);
        CHAT_OPENING_SMOOTHNESS = BUILDER
                .comment("Chat opening animation smoothness. 0 = Off, 1 = Maximum smoothness")
                .defineInRange("openingSmoothness", 0.5, 0.0, 1.0);
        BUILDER.pop();
        
        BUILDER.push("creativeScreen");
        CREATIVE_SCREEN_SMOOTHNESS = BUILDER
                .comment("Creative screen scroll smoothness. 0 = Off, 1 = Maximum smoothness")
                .defineInRange("smoothness", 0.5, 0.0, 1.0);
        BUILDER.pop();
        
        BUILDER.push("entryList");
        ENTRY_LIST_SMOOTHNESS = BUILDER
                .comment("Entry list scroll smoothness. 0 = Off, 1 = Maximum smoothness")
                .defineInRange("smoothness", 0.5, 0.0, 1.0);
        ENTRY_LIST_SPEED = BUILDER
                .comment("Entry list scroll speed in pixels. 0 = Auto, max 100")
                .defineInRange("speed", 30.0, 0.0, 100.0);
        BUILDER.pop();
        
        BUILDER.push("misc");
        ENABLE_MASK_DEBUG = BUILDER
                .comment("Enable mask debug visualization")
                .define("enableMaskDebug", false);
        BUILDER.pop();
    }
    
    public static final ModConfigSpec SPEC = BUILDER.build();
}
