package com.leclowndu93150.smoothscrolling.mixin.Chat;

import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.CommandSuggestions.SuggestionsList;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.util.FastColor;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.mojang.brigadier.suggestion.Suggestion;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;

@Mixin(SuggestionsList.class)
public class SuggestionWindowMixin {
    @Shadow private int offset;
    @Final @Shadow private List<Suggestion> suggestionList;
    @Final @Shadow private Rect2i rect;

    @Unique private int indexBefore;
    @Unique private float scrollPixelOffset;
    @Unique private int targetIndex;

    @Inject(method = "render", at = @At("HEAD"))
    private void renderH(GuiGraphics context, int mouseX, int mouseY, CallbackInfo ci) {
        if(Config.CHAT_SMOOTHNESS.get() == 0) return;
        scrollPixelOffset = (float) (scrollPixelOffset * Math.pow(Config.CHAT_SMOOTHNESS.get(), SmoothSc.getLastFrameDuration()));
        offset = SmoothSc.clamp(targetIndex - getScrollOffset() / 12, 0, suggestionList.size() - 10); // the clamp is here as a workaround to a crash
    }
    /*@ModifyVariable(method = "render", at = @At(value = "STORE"), ordinal = 4) idk why this doesn't work
    private boolean mask(boolean a) {
        SmoothSc.print(a);
        savedContext.enableScissor(rect.getX() - 1, rect.getY(), rect.getX() + rect.getWidth() + 1, rect.getY() + rect.getHeight());
        return (a);
    }/* */

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;fill(IIIII)V", ordinal = 4))
    private void mask(GuiGraphics context, int mouseX, int mouseY, CallbackInfo ci) {
        if(Config.CHAT_SMOOTHNESS.get() == 0) return;
        // savedContext.enableScissor(rect.getX() - 1, rect.getY(), rect.getX() + rect.getWidth(), rect.getY() + rect.getHeight());
        context.enableScissor(0, rect.getY(), context.guiWidth(), rect.getY() + rect.getHeight());
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)I", shift = At.Shift.AFTER))
    private void demask(GuiGraphics context, int mouseX, int mouseY, CallbackInfo ci) {
        if(Config.CHAT_SMOOTHNESS.get() == 0) return;
        if (Config.ENABLE_MASK_DEBUG.get())
            context.fill(-100, -100, context.guiWidth(), context.guiHeight(), FastColor.ARGB32.color(50, 255, 255, 0));
        context.disableScissor();
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void renderT(GuiGraphics context, int mouseX, int mouseY, CallbackInfo ci) {
        if(Config.CHAT_SMOOTHNESS.get() == 0) return;
        offset = targetIndex;
    }

    @ModifyArg(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;drawString(Lnet/minecraft/client/gui/Font;Ljava/lang/String;III)I"), index = 3)
    private int textPosY(int s) {
        if(Config.CHAT_SMOOTHNESS.get() == 0) return (s);
        return (s + getDrawOffset());
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"))
    private void mScrollH(double am, CallbackInfoReturnable<Boolean> ci) {commonSH();}
    @Inject(method = "mouseScrolled", at = @At("RETURN"))
    private void mScrollT(double am, CallbackInfoReturnable<Boolean> ci) {commonST();}
    @Inject(method = "cycle", at = @At("HEAD"))
    private void scrollH(int off, CallbackInfo ci) {commonSH();}
    @Inject(method = "cycle", at = @At("TAIL"))
    private void scrollT(int off, CallbackInfo ci) {commonST();}

    @Unique
    private void commonSH(){
        if(Config.CHAT_SMOOTHNESS.get() == 0) return;
        indexBefore = offset;
    }

    @Unique
    private void commonST(){
        if(Config.CHAT_SMOOTHNESS.get() == 0) return;
        scrollPixelOffset += (offset - indexBefore) * 12;
        targetIndex = offset;
        offset = indexBefore;
    }

    @ModifyVariable(method = "render", at = @At("STORE"), ordinal = 4)
    private int addLineAbove(int r) { // this function gets called three times for just one line for some reason
        if (Config.CHAT_SMOOTHNESS.get() == 0 || getScrollOffset() <= 0 || offset <= 0) return (r);
        return (r - 1);
    }

    @ModifyVariable(method = "render", at = @At("STORE"), ordinal = 2)
    private int addLineUnder(int i) {
        if (Config.CHAT_SMOOTHNESS.get() == 0 || getScrollOffset() >= 0 || offset >= suggestionList.size() - 10) return (i);
        return (i + 1);
    }

    @Unique
    private int getDrawOffset() {
        return Math.round(scrollPixelOffset) - (Math.round(scrollPixelOffset) / 12 * 12);
    }

    @Unique
    private int getScrollOffset() {
        return Math.round(scrollPixelOffset);
    }
}
