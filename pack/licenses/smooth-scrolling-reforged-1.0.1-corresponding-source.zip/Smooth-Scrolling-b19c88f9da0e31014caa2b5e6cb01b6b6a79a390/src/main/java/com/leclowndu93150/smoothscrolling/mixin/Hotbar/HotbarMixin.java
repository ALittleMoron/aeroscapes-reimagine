package com.leclowndu93150.smoothscrolling.mixin.Hotbar;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import net.minecraft.world.entity.player.Inventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;

@Mixin(value = Gui.class, priority = 999) // if bedrockify applies its mixin before smoothsc, modifyarg crashes
public class HotbarMixin {

	@Unique private int rolloverOffsetR = 4; // TODO
	@Unique private int rolloverOffsetL = 4;
	@Unique private int rolloverOffset = 4;
	@Unique private float selectedPixelBuffer = 0;
	@Unique private boolean masked = false;

	@Inject(method = "renderItemHotbar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lnet/minecraft/resources/ResourceLocation;IIII)V", ordinal = 1))
	private void draw1(GuiGraphics context, DeltaTracker rtc, CallbackInfo ci) {
		if (Config.HOTBAR_SMOOTHNESS.get() == 0) return;
	}

	@ModifyArgs(method = "renderItemHotbar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lnet/minecraft/resources/ResourceLocation;IIII)V", ordinal = 1))
	private void selectedSlotX(Args args, @Local(argsOnly = true) GuiGraphics context) {
		if (Config.HOTBAR_SMOOTHNESS.get() == 0) return;
		ResourceLocation texture = args.get(0);
		int x = args.get(1);
		int y = args.get(2);
		int width = args.get(3);
		int height = args.get(4);
		Inventory inv = SmoothSc.mc.player.getInventory();

		var target = (inv.selected - SmoothSc.hotbarRollover * 9) * 20 - SmoothSc.hotbarRollover * rolloverOffset;
		selectedPixelBuffer = (float) ((selectedPixelBuffer - target) * Math.pow(Config.HOTBAR_SMOOTHNESS.get(), SmoothSc.getLastFrameDuration()) + target);
		
		if (Math.round(selectedPixelBuffer) < -10 - rolloverOffset) {
			selectedPixelBuffer += 9 * 20 + rolloverOffset;
			SmoothSc.hotbarRollover -= 1;
		} else if (Math.round(selectedPixelBuffer) > 20 * 9 - 10 + rolloverOffset) {
			selectedPixelBuffer -= 9 * 20 + rolloverOffset;
			SmoothSc.hotbarRollover += 1;
		}

		x -= inv.selected * 20;
		x += Math.round(selectedPixelBuffer);
		args.set(1, x);

		masked = false;
		if (Math.round(selectedPixelBuffer) < 0) {
			enableMask(context);
			SmoothSc.drawHotbarRolloverMirror(context, texture, x, 9 * 20, rolloverOffset, y, width, height);
		} else if (Math.round(selectedPixelBuffer) > 20 * 8) {
			enableMask(context);
			SmoothSc.drawHotbarRolloverMirror(context, texture, x, -9 * 20, -rolloverOffset, y, width, height);
		}
	}

	@Inject(method = "renderItemHotbar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lnet/minecraft/resources/ResourceLocation;IIII)V", ordinal = 1, shift = At.Shift.AFTER))
	private void draw2(GuiGraphics context, DeltaTracker rtc, CallbackInfo ci) {
		if (!masked) return;
        if (Config.ENABLE_MASK_DEBUG.get()) context.fill(-100, -100, context.guiWidth(), context.guiHeight(), FastColor.ARGB32.color(50, 0, 255, 255));
		context.disableScissor();
	}

	@Unique
	private void enableMask(GuiGraphics context) {
		var x2 = context.guiWidth() / 2 - 91;
		var y2 = context.guiHeight() - 22;
		//if (FabricLoader.getInstance().getObjectShare().get("raised:hud") instanceof Integer distance) y2 -= distance;
		var mtpos = SmoothSc.getMatrixTranslate(context);
		context.enableScissor((int) mtpos.x + x2 - 1, (int) mtpos.y + y2 - 1, (int) mtpos.x + x2 + 182 + 1, (int) mtpos.y + y2 + 22 + 1);
		masked = true;
	}
}
