package com.leclowndu93150.smoothscrolling.mixin.Hotbar;

import net.minecraft.world.entity.player.Inventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;

@Mixin(Inventory.class)
public class PlayerInventoryMixin {

    @Inject(method = "swapPaint", at = @At("HEAD"))
    private void scrollH(double d, CallbackInfo ci) {
        if (!Config.HOTBAR_ROLLOVER.get()) return;
        var s = Math.signum(d);
        Inventory inv = SmoothSc.mc.player.getInventory();
        if (inv.selected - s < 0) SmoothSc.hotbarRollover += 1;
        if (inv.selected - s > 8) SmoothSc.hotbarRollover += -1;
    }
}
