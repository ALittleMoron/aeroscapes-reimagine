package com.leclowndu93150.smoothscrolling.mixin.creative_screen;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FastColor;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalDoubleRef;
import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;

@Mixin(value = AbstractContainerScreen.class, priority = 999)
public abstract class HandledScreenMixin<T extends AbstractContainerMenu> {

    @Shadow @Final protected T menu;

    @Shadow protected abstract void renderSlot(GuiGraphics context, Slot slot);

    @Unique private final ResourceLocation backTex = ResourceLocation.withDefaultNamespace("textures/gui/container/creative_inventory/tab_items");
    @Unique private boolean cutEnabled = false;
    @Unique private int originalCursorY;
    @Unique private boolean drawingOverdrawnSlot = false;

    @Inject(method = "render", at = @At("HEAD"))
    private void render(GuiGraphics context, int mx, int my, float d, CallbackInfo ci) {
        this.originalCursorY = my;
        if (Config.CREATIVE_SCREEN_SMOOTHNESS.get() == 0 || SmoothSc.creativeSH == null || SmoothSc.getCreativeScrollOffset() == 0) return;

        SmoothSc.creativeScreenScrollOffset = (float) ((SmoothSc.creativeScreenScrollOffset) * Math.pow(Config.CREATIVE_SCREEN_SMOOTHNESS.get(), SmoothSc.getLastFrameDuration()));

        SmoothSc.creativeScreenScrollMixin = false;
        SmoothSc.creativeSH.scrollTo(((CreativeScreenHandlerAccessor) SmoothSc.creativeSH)
                .getPos(SmoothSc.creativeScreenPrevRow - SmoothSc.getCreativeScrollOffset() / 18));
        SmoothSc.creativeScreenScrollMixin = true;

    }

    @Inject(method = "render", at = @At(shift = At.Shift.AFTER, value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V"))
    private void renderMid0(GuiGraphics context, int mx, int my, float d, CallbackInfo ci, @Local(ordinal = 1, argsOnly = true) LocalIntRef mouseY) {
        if (Config.CREATIVE_SCREEN_SMOOTHNESS.get() == 0 || SmoothSc.creativeScreenItemCount <= 0 || SmoothSc.getCreativeScrollOffset() == 0) return;
        //SmoothSc.print("popopopo");
        context.enableScissor(0, context.guiHeight() / 2 - 50, context.guiWidth(), context.guiHeight() / 2 + 38);
        context.pose().pushPose();
        context.pose().translate(0, SmoothSc.getCreativeDrawOffset(), 0);
        cutEnabled = true;
        if(originalCursorY >= context.guiHeight() / 2 - 51 && originalCursorY <= context.guiHeight() / 2 + 38)
            mouseY.set(my - SmoothSc.getCreativeDrawOffset());

        // the fix for instantly disappearing items on the opposite side of scrolling...
        // it gets the items that just left the slots and draws them in the correct
        // position
        var overUnder = SmoothSc.getCreativeScrollOffset() < 0 ? 9 * 5 : -9;
        var currRow = SmoothSc.creativeScreenPrevRow - SmoothSc.getCreativeScrollOffset() / 18;
        var fromIndex = currRow * 9 + overUnder;
        for(int i = fromIndex; i >= 0 && i < SmoothSc.creativeSH.items.size() && i < fromIndex + 9; i++) {
            var tempSlot = new Slot(SmoothSc.getDelegatingInventory(this.menu), i, 9 + i % 9 * 18, SmoothSc.getCreativeScrollOffset() > 0 ? 0 : 18 * 6);

            this.drawSlotOverridden(context, tempSlot);
        }
    }

    @Unique
    private void drawSlotOverridden(GuiGraphics context, Slot slot) {
        this.drawingOverdrawnSlot = true;
        this.renderSlot(context, slot);
        this.drawingOverdrawnSlot = false;
    }

    @ModifyVariable(method = "renderSlot", at = @At(value = "STORE"), ordinal = 1)
    private int drawItemY(int y, @Local(argsOnly = true) GuiGraphics context) {
        if(drawingOverdrawnSlot) return y;
        SmoothSc.creativeScreenItemCount -= 1;
        if (SmoothSc.creativeScreenItemCount < 0) tryDisableMask(context);
        if (Config.CREATIVE_SCREEN_SMOOTHNESS.get() == 0 || SmoothSc.creativeScreenItemCount < 0) return y;
        return y ;//+ SmoothSc.getCreativeDrawOffset();
    }

    @ModifyVariable(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;renderSlot(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/world/inventory/Slot;)V", shift = At.Shift.AFTER), argsOnly = true, ordinal = 1)
    private int revertMousePos(int mouseY) {
        if (Config.CREATIVE_SCREEN_SMOOTHNESS.get() == 0 || SmoothSc.creativeScreenItemCount < 0) return originalCursorY;
        return mouseY;
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target ="Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;renderLabels(Lnet/minecraft/client/gui/GuiGraphics;II)V"))
    private void renderMid1(GuiGraphics context, int mx, int my, float d, CallbackInfo ci, @Local(ordinal = 1, argsOnly = true) LocalIntRef mouseY) {
        tryDisableMask(context);
        mouseY.set(originalCursorY);
    }

    @Inject(method = "mouseClicked", at = @At(value = "HEAD"))
    private void mouseClickedMid1(double mouseX, double my, int button, CallbackInfoReturnable<Boolean> ci, @Local(ordinal = 1, argsOnly = true) LocalDoubleRef mouseY) {
        if (isInBounds((int) mouseX, (int) mouseY.get()) && isInBounds((int) mouseX, (int) mouseY.get() - SmoothSc.getCreativeDrawOffset()))
            mouseY.set(my - SmoothSc.getCreativeDrawOffset());
    }


    @Unique
    private void tryDisableMask(GuiGraphics context){
        if (drawingOverdrawnSlot) return;
        if (!cutEnabled) return;
        if (Config.ENABLE_MASK_DEBUG.get())
            context.fill(-100, -100, context.guiWidth(), context.guiHeight(), FastColor.ARGB32.color(50, 0, 255, 255));
        context.disableScissor();
        context.pose().popPose();
        cutEnabled = false;
    }
    @Unique
    private boolean isInBounds(int x, int y) {
        return y >= SmoothSc.mc.getWindow().getGuiScaledHeight() / 2 - 51 && y <= SmoothSc.mc.getWindow().getGuiScaledHeight() / 2 + 38;
    }
    //@ModifyArg(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/ingame/HandledScreen;isPointOverSlot(Lnet/minecraft/screen/slot/Slot;DD)Z"), index = 2)
    //double modifyCursorPosY(double my) {
    //    if(!cutEnabled || originalCursorY < savedContext.getScaledWindowHeight() / 2 - 51 || originalCursorY > savedContext.getScaledWindowHeight() / 2 + 38) return my;
    //    return originalCursorY - SmoothSc.getCreativeDrawOffset();
    //}
}