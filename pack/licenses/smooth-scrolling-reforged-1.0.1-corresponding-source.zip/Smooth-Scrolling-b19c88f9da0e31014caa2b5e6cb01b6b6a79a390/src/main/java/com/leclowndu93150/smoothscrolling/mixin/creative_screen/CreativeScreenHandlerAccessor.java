package com.leclowndu93150.smoothscrolling.mixin.creative_screen;

import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen.ItemPickerMenu;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ItemPickerMenu.class)
public interface CreativeScreenHandlerAccessor {
    @Invoker("getScrollForRowIndex")
    float getPos(int row);
}
