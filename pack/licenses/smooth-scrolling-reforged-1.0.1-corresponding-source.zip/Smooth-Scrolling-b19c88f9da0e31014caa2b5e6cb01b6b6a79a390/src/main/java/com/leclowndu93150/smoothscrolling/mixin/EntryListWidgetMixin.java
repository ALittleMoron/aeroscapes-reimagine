package com.leclowndu93150.smoothscrolling.mixin;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSelectionList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;
import com.leclowndu93150.smoothscrolling.SmoothScrolling;

@Mixin(AbstractSelectionList.class)
public class EntryListWidgetMixin {
    @Shadow private double scrollAmount; // this is the number of pixels

    @Unique private double scrollAmountBuffer;
    @Unique private double targetScroll;
    @Unique private boolean mousescrolling = false;

    @Unique private double prevScrollVal;
    @Unique private boolean updateScActive = false; // this makes the mod know, when things aren't working as expected and lets the user scroll non-smoothly

    @Inject(method = "setScrollAmount", at = @At("TAIL"))
    private void setScrollT(double s, CallbackInfo ci) {
        if (mousescrolling) return;
        targetScroll = scrollAmount;
        scrollAmountBuffer = scrollAmount;
    }

    @Inject(method = "renderWidget", at = @At("HEAD"), require = 0)
    private void updateScroll(GuiGraphics dc, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        double smoothness = SmoothScrolling.isSmoothScrollingRefurbishedLoaded ? 0 : Config.ENTRY_LIST_SMOOTHNESS.get();
        if (smoothness == 0) return;
        updateScActive = true;

        scrollAmountBuffer = (scrollAmountBuffer - targetScroll) * Math.pow(smoothness, SmoothSc.getLastFrameDuration()) + targetScroll;
        scrollAmount = Math.round(scrollAmountBuffer);
    }

    @Inject(method = "mouseScrolled", at = @At("HEAD"), require = 0)
    private void mouseScrollH(double mouseX, double mouseY, double hA, double vA, CallbackInfoReturnable<Boolean> cir) {
        double smoothness = SmoothScrolling.isSmoothScrollingRefurbishedLoaded ? 0 : Config.ENTRY_LIST_SMOOTHNESS.get();
        if (smoothness == 0 || !updateScActive) return;
        mousescrolling = true;
        prevScrollVal = scrollAmount;
        setScrollAmount(targetScroll);
    }

    @Inject(method = "mouseScrolled", at = @At("TAIL"), require = 0)
    private void mouseScrollT(double mouseX, double mouseY, double hA, double vA, CallbackInfoReturnable<Boolean> cir) {
        var diff = scrollAmount - targetScroll;
        if (Config.ENTRY_LIST_SPEED.get() != 0)
            diff = - Config.ENTRY_LIST_SPEED.get() * vA;
        setScrollAmount(targetScroll + diff);
        
        double smoothness = SmoothScrolling.isSmoothScrollingRefurbishedLoaded ? 0 : Config.ENTRY_LIST_SMOOTHNESS.get();
        if (smoothness == 0 || !updateScActive) return;

        targetScroll = scrollAmount;
        setScrollAmount(prevScrollVal);
        mousescrolling = false;
    }

    @Shadow
    public void setScrollAmount(double sc) {}
}
