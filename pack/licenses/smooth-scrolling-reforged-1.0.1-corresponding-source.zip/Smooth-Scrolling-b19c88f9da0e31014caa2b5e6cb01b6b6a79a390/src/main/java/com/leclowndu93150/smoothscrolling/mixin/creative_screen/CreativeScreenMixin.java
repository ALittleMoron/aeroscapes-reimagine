package com.leclowndu93150.smoothscrolling.mixin.creative_screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.util.FastColor;
import net.minecraft.world.item.CreativeModeTab;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.leclowndu93150.smoothscrolling.SmoothSc;
import com.leclowndu93150.smoothscrolling.Config;

@Mixin(CreativeModeInventoryScreen.class)
public class CreativeScreenMixin {

    @Shadow
    private static CreativeModeTab selectedTab;

    @Inject(method = "selectTab", at = @At("TAIL"))
    private void setSelectedTabT(CreativeModeTab group, CallbackInfo ci) {
        SmoothSc.creativeScreenScrollOffset = 0;
    }

    @Inject(method = "renderBg", at = @At(value = "INVOKE", shift = Shift.AFTER, target = "Lnet/minecraft/client/gui/GuiGraphics;blit(Lnet/minecraft/resources/ResourceLocation;IIIIII)V"))
    private void drawBackground(GuiGraphics context, float delta, int mouseX, int mouseY, CallbackInfo ci) {
        if (SmoothSc.getCreativeScrollOffset() == 0 || Config.CREATIVE_SCREEN_SMOOTHNESS.get() == 0 || SmoothSc.creativeSH == null) return;

        int x0 = Math.round(context.guiWidth() / 2f) - 90;
        int y0 = context.guiHeight() / 2 - 51;
        int x1 = 162;
        int y1 = 90;
        int x2 = 8;
        int y2 = 17;

        //context.drawText(SmoothSc.mc.textRenderer, mouseX + " - " + mouseY, 10, 10, ColorHelper.Argb.getArgb(255, 0, 255, 255), true);
        //context.fill(0, 0, 1920, 1080, ColorHelper.Argb.getArgb(50, 255, 128, 0));
        context.enableScissor(x0, y0 + 1, x0 + x1, y0 + y1 - 1);
        context.blit(selectedTab.getBackgroundTexture(), x0, 
            y0 + SmoothSc.getCreativeDrawOffset(),
                x2, y2, x1, y1);
        context.blit(selectedTab.getBackgroundTexture(), x0,
            (int) (y0 + SmoothSc.getCreativeDrawOffset() - y1 * Math.signum(SmoothSc.getCreativeScrollOffset())),
                x2, y2, x1, y1);

        if (Config.ENABLE_MASK_DEBUG.get())
            context.fill(-100, -100, context.guiWidth(), context.guiHeight(), FastColor.ARGB32.color(50, 255, 255, 0));
        
        context.disableScissor();
    }
}
