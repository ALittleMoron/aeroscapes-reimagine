package com.leclowndu93150.smoothscrolling;

import com.mojang.logging.LogUtils;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import org.slf4j.Logger;

@Mod(value = SmoothScrolling.MODID, dist = Dist.CLIENT)
public class SmoothScrolling {
    public static final String MODID = "smoothscrolling";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static boolean isSmoothScrollingRefurbishedLoaded;
    public static boolean isCondensedInventoryLoaded;

    public SmoothScrolling(IEventBus modEventBus, ModContainer modContainer) {
        modEventBus.addListener(this::clientSetup);
        
        modContainer.registerConfig(ModConfig.Type.CLIENT, Config.SPEC);
        
        modContainer.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
        
        isSmoothScrollingRefurbishedLoaded = ModList.get().isLoaded("smoothscrollingrefurbished");
        isCondensedInventoryLoaded = ModList.get().isLoaded("condensed_creative");
        
        if (isSmoothScrollingRefurbishedLoaded) {
            LOGGER.info("Smooth Scrolling Refurbished is loaded! Entry list smoothing will be disabled in favor of the other mod.");
        }
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        LOGGER.info("Smooth Scrolling client setup complete");
    }
}
