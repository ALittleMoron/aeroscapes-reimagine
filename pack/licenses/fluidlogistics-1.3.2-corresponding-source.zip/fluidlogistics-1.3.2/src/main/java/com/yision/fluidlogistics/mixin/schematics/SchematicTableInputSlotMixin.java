package com.yision.fluidlogistics.mixin.schematics;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.yision.fluidlogistics.registry.AllItems;

import net.minecraft.world.item.ItemStack;

@Mixin(targets = "com.simibubi.create.content.schematics.table.SchematicTableMenu$1")
public class SchematicTableInputSlotMixin {

	@Inject(method = "mayPlace", at = @At("HEAD"), cancellable = true)
	private void fluidlogistics$acceptFluidSchematics(
		ItemStack stack, CallbackInfoReturnable<Boolean> cir) {
		if (AllItems.EMPTY_FLUID_SCHEMATIC.isIn(stack) || AllItems.FLUID_SCHEMATIC.isIn(stack)) {
			cir.setReturnValue(true);
		}
	}
}
