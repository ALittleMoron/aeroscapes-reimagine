package com.yision.fluidlogistics.content.equipment.handPointer.filter;

import java.util.Optional;

import com.simibubi.create.foundation.utility.IInteractionChecker;
import com.yision.fluidlogistics.content.equipment.handPointer.HandPointerItem;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

public class HandPointerFilterTarget implements MenuProvider, IInteractionChecker {

	private final BlockPos pos;
	private final Direction side;
	private final Vec3 hitLocation;
	private final ItemStack iconStack;
	private final boolean requiresHandPointer;

	public HandPointerFilterTarget(BlockPos pos, Direction side, Vec3 hitLocation, ItemStack iconStack) {
		this(pos, side, hitLocation, iconStack, true);
	}

	public HandPointerFilterTarget(BlockPos pos, Direction side, Vec3 hitLocation, ItemStack iconStack,
		boolean requiresHandPointer) {
		this.pos = pos;
		this.side = side;
		this.hitLocation = hitLocation;
		this.iconStack = iconStack;
		this.requiresHandPointer = requiresHandPointer;
	}

	public BlockPos pos() {
		return pos;
	}

	public Direction side() {
		return side;
	}

	public Vec3 hitLocation() {
		return hitLocation;
	}

	public ItemStack iconStack() {
		return iconStack;
	}

	@Override
	public Component getDisplayName() {
		return iconStack.getHoverName();
	}

	@Override
	public AbstractContainerMenu createMenu(int containerId, Inventory playerInventory, Player player) {
		return HandPointerFilterMenu.create(containerId, playerInventory, this);
	}

	@Override
	public boolean canPlayerUse(Player player) {
		if (player.isSpectator()) {
			return false;
		}

		Level playerLevel = player.level();
		if (!playerLevel.isLoaded(pos)) {
			return false;
		}

		if (player.distanceToSqr(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D) > 64.0D) {
			return false;
		}

		if (requiresHandPointer && !(player.getMainHandItem().getItem() instanceof HandPointerItem)) {
			return false;
		}

		Optional<HandPointerFilterTarget> current = HandPointerFilterTargetResolver.resolve(playerLevel, player, pos,
			buildHitResult(playerLevel));
		return current.isPresent();
	}

	private BlockHitResult buildHitResult(Level level) {
		return new BlockHitResult(hitLocation, side, pos, false);
	}

	public void encode(RegistryFriendlyByteBuf buf) {
		BlockPos.STREAM_CODEC.encode(buf, pos);
		Direction.STREAM_CODEC.encode(buf, side);
		buf.writeDouble(hitLocation.x);
		buf.writeDouble(hitLocation.y);
		buf.writeDouble(hitLocation.z);
		ItemStack.OPTIONAL_STREAM_CODEC.encode(buf, iconStack);
		buf.writeBoolean(requiresHandPointer);
	}

	public static HandPointerFilterTarget decodeClient(RegistryFriendlyByteBuf buf) {
		BlockPos pos = BlockPos.STREAM_CODEC.decode(buf);
		Direction side = Direction.STREAM_CODEC.decode(buf);
		Vec3 hitLocation = new Vec3(buf.readDouble(), buf.readDouble(), buf.readDouble());
		ItemStack iconStack = ItemStack.OPTIONAL_STREAM_CODEC.decode(buf);
		boolean requiresHandPointer = buf.readBoolean();
		return new HandPointerFilterTarget(pos, side, hitLocation, iconStack, requiresHandPointer);
	}
}
