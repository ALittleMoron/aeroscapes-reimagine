package com.yision.fluidlogistics.content.equipment.mechanicalFluidGun.handler;

import com.yision.fluidlogistics.FluidLogistics;
import com.yision.fluidlogistics.content.equipment.mechanicalFluidGun.MechanicalFluidGunBlock;
import com.yision.fluidlogistics.registry.AllBlocks;

import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

@EventBusSubscriber(modid = FluidLogistics.MODID)
public class MechanicalFluidGunTargetUseBlocker {

	@SubscribeEvent(priority = EventPriority.HIGHEST)
	public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
		Level level = event.getLevel();
		if (level.isClientSide()) {
			return;
		}

		Player player = event.getEntity();
		if (player.isSpectator()
			|| player.isShiftKeyDown()
			|| !AllBlocks.MECHANICAL_FLUID_GUN.isIn(player.getMainHandItem())) {
			return;
		}

		if (!MechanicalFluidGunBlock.isTargetTagged(level, event.getPos())) {
			return;
		}

		event.setCanceled(true);
		event.setCancellationResult(InteractionResult.SUCCESS);
	}
}
