package com.yision.fluidlogistics.content.fluids.fluidPump;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.Set;

import com.google.common.collect.ImmutableList;
import com.simibubi.create.content.fluids.FluidPropagator;
import com.simibubi.create.content.fluids.FluidTransportBehaviour;
import com.simibubi.create.content.fluids.PipeConnection;
import com.simibubi.create.content.fluids.pump.PumpBlock;
import com.simibubi.create.content.fluids.pump.PumpBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsBoard;
import com.simibubi.create.foundation.blockEntity.behaviour.ValueSettingsFormatter.ScrollOptionSettingsFormatter;
import com.simibubi.create.foundation.blockEntity.behaviour.scrollValue.ScrollOptionBehaviour;
import com.yision.fluidlogistics.infrastructure.config.Config;

import net.createmod.catnip.data.Couple;
import net.createmod.catnip.data.Pair;
import net.createmod.catnip.math.BlockFace;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

import net.neoforged.neoforge.capabilities.Capabilities;

public class FluidPumpBlockEntity extends PumpBlockEntity {

	public static final float PRESSURE_MULTIPLIER = 2.0f;

	private boolean fluidPumpPressureUpdate;
	private boolean registeredForPropagation;
	private ScrollOptionBehaviour<FluidTransferDirection> directionSelector;

	public FluidPumpBlockEntity(BlockEntityType<?> typeIn, BlockPos pos, BlockState state) {
		super(typeIn, pos, state);
	}

	public void setPressureUpdate(boolean value) {
		this.fluidPumpPressureUpdate = value;
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
		super.addBehaviours(behaviours);

		directionSelector = new ScrollOptionBehaviour<>(
			FluidTransferDirection.class,
			Component.translatable("fluidlogistics.fluid_pump.transfer_direction"),
			this, new FluidPumpDirectionSlot()) {
			@Override
			public ValueSettingsBoard createBoard(Player player, BlockHitResult hitResult) {
				return new ValueSettingsBoard(label, max, 1, ImmutableList.of(label),
					new ScrollOptionSettingsFormatter(
						FluidTransferDirection.guiOptions(FluidPumpBlock.getFluidAxis(getBlockState()))));
			}

			@Override
			public void read(CompoundTag nbt, HolderLookup.Provider registries, boolean clientPacket) {
				syncDirectionSelectorWithBlockState();
			}

			@Override
			public void write(CompoundTag nbt, HolderLookup.Provider registries, boolean clientPacket) {
			}
		};
		directionSelector.withCallback(this::onDirectionSelected);
		syncDirectionSelectorWithBlockState();
		behaviours.add(directionSelector);
	}

	@Override
	public void initialize() {
		super.initialize();
		registerForPropagation();
		syncDirectionSelectorWithBlockState();
	}

	private void registerForPropagation() {
		if (registeredForPropagation || level == null || level.isClientSide)
			return;
		registeredForPropagation = true;
		FluidPumpNetworkUpdater.onFluidPumpLoaded(level);
	}

	@Override
	public void invalidate() {
		unregisterForPropagation();
		super.invalidate();
	}

	private void unregisterForPropagation() {
		if (!registeredForPropagation || level == null || level.isClientSide)
			return;
		registeredForPropagation = false;
		FluidPumpNetworkUpdater.onFluidPumpUnloaded(level);
	}

	private void syncDirectionSelectorWithBlockState() {
		if (directionSelector != null)
			directionSelector.value = FluidTransferDirection
				.fromAxisDirection(getBlockState().getValue(PumpBlock.FACING).getAxisDirection()).ordinal();
	}

	@Override
	public void setBlockState(BlockState state) {
		super.setBlockState(state);
		syncDirectionSelectorWithBlockState();
	}

	private void onDirectionSelected(int newOrdinal) {
		if (level == null || level.isClientSide || newOrdinal < 0
			|| newOrdinal >= FluidTransferDirection.values().length)
			return;
		BlockState state = getBlockState();
		Direction output = Direction.fromAxisAndDirection(FluidPumpBlock.getFluidAxis(state),
			FluidTransferDirection.values()[newOrdinal].getAxisDirection());
		if (output != state.getValue(PumpBlock.FACING))
			level.setBlockAndUpdate(worldPosition, state.setValue(PumpBlock.FACING, output));
	}

	@Override
	public void tick() {
		if ((!level.isClientSide || isVirtual()) && fluidPumpPressureUpdate) {
			fluidPumpPressureUpdate = false;
			updatePressureChange();
		}
		super.tick();
		FluidTransportBehaviour transport = getBehaviour(FluidTransportBehaviour.TYPE);
		float pumpPressure = Math.abs(getSpeed()) * PRESSURE_MULTIPLIER;
		for (Entry<Direction, PipeConnection> entry : transport.interfaces.entrySet()) {
			boolean pull = isPullingOnSide(isFront(entry.getKey()));
			Couple<Float> pressure = entry.getValue().getPressure();
			pressure.set(pull, pumpPressure);
			pressure.set(!pull, 0f);
		}
	}

	@Override
	protected void distributePressureTo(Direction side) {
		if (getSpeed() == 0)
			return;

		BlockFace start = new BlockFace(worldPosition, side);
		boolean pull = isPullingOnSide(isFront(side));
		Set<BlockFace> targets = new HashSet<>();
		Map<BlockPos, Pair<Integer, Map<Direction, Boolean>>> pipeGraph = new HashMap<>();

		if (!pull)
			FluidPropagator.resetAffectedFluidNetworks(level, worldPosition, side.getOpposite());

		if (!hasReachedValidEndpoint(level, start, pull)) {

			pipeGraph.computeIfAbsent(worldPosition, $ -> Pair.of(0, new IdentityHashMap<>()))
				.getSecond()
				.put(side, pull);
			pipeGraph.computeIfAbsent(start.getConnectedPos(), $ -> Pair.of(1, new IdentityHashMap<>()))
				.getSecond()
				.put(side.getOpposite(), !pull);

			Queue<Pair<Integer, BlockPos>> frontier = new ArrayDeque<>();
			Set<BlockPos> visited = new HashSet<>();
			int maxDistance = Config.getFluidPumpRange();
			frontier.add(Pair.of(1, start.getConnectedPos()));

			while (!frontier.isEmpty()) {
				Pair<Integer, BlockPos> entry = frontier.poll();
				int distance = entry.getFirst();
				BlockPos currentPos = entry.getSecond();

				if (!level.isLoaded(currentPos))
					continue;
				if (visited.contains(currentPos))
					continue;
				visited.add(currentPos);
				BlockState currentState = level.getBlockState(currentPos);
				FluidTransportBehaviour pipe = FluidPropagator.getPipe(level, currentPos);
				if (pipe == null)
					continue;

				for (Direction face : FluidPropagator.getPipeConnections(currentState, pipe)) {
					BlockFace blockFace = new BlockFace(currentPos, face);
					BlockPos connectedPos = blockFace.getConnectedPos();

					if (!level.isLoaded(connectedPos))
						continue;
					if (blockFace.isEquivalent(start))
						continue;
					if (hasReachedValidEndpoint(level, blockFace, pull)) {
						pipeGraph.computeIfAbsent(currentPos, $ -> Pair.of(distance, new IdentityHashMap<>()))
							.getSecond()
							.put(face, pull);
						targets.add(blockFace);
						continue;
					}

					FluidTransportBehaviour pipeBehaviour = FluidPropagator.getPipe(level, connectedPos);
					if (pipeBehaviour == null)
						continue;
					if (isPumpTransferBehaviour(pipeBehaviour))
						continue;
					if (visited.contains(connectedPos))
						continue;
					if (distance + 1 >= maxDistance) {
						pipeGraph.computeIfAbsent(currentPos, $ -> Pair.of(distance, new IdentityHashMap<>()))
							.getSecond()
							.put(face, pull);
						targets.add(blockFace);
						continue;
					}

					pipeGraph.computeIfAbsent(currentPos, $ -> Pair.of(distance, new IdentityHashMap<>()))
						.getSecond()
						.put(face, pull);
					pipeGraph.computeIfAbsent(connectedPos, $ -> Pair.of(distance + 1, new IdentityHashMap<>()))
						.getSecond()
						.put(face.getOpposite(), !pull);
					frontier.add(Pair.of(distance + 1, connectedPos));
				}
			}
		}

		Map<Integer, Set<BlockFace>> validFaces = new HashMap<>();
		searchForEndpointRecursively(pipeGraph, targets, validFaces,
			new BlockFace(start.getPos(), start.getOppositeFace()), pull);

		float pressure = Math.abs(getSpeed()) * PRESSURE_MULTIPLIER;
		for (Set<BlockFace> set : validFaces.values()) {
			int parallelBranches = Math.max(1, set.size() - 1);
			for (BlockFace face : set) {
				BlockPos pipePos = face.getPos();
				Direction pipeSide = face.getFace();

				if (pipePos.equals(worldPosition))
					continue;

				boolean inbound = pipeGraph.get(pipePos)
					.getSecond()
					.get(pipeSide);
				FluidTransportBehaviour pipeBehaviour = FluidPropagator.getPipe(level, pipePos);
				if (pipeBehaviour == null)
					continue;

				pipeBehaviour.addPressure(pipeSide, inbound, pressure / parallelBranches);
			}
		}
	}

	private boolean isPumpTransferBehaviour(FluidTransportBehaviour behaviour) {
		return behaviour.blockEntity instanceof PumpBlockEntity;
	}

	private boolean hasReachedValidEndpoint(LevelAccessor world, BlockFace blockFace, boolean pull) {
		BlockPos connectedPos = blockFace.getConnectedPos();
		BlockState connectedState = world.getBlockState(connectedPos);
		BlockEntity blockEntity = world.getBlockEntity(connectedPos);
		Direction face = blockFace.getFace();

		if (PumpBlock.isPump(connectedState) && connectedState.getValue(PumpBlock.FACING).getAxis() == face.getAxis()
			&& blockEntity instanceof PumpBlockEntity pumpBE) {
			Direction pumpFront = connectedState.getValue(PumpBlock.FACING);
			boolean pumpFrontSide = blockFace.getOppositeFace() == pumpFront;
			return pumpBE.isPullingOnSide(pumpFrontSide) != pull;
		}

		FluidTransportBehaviour pipe = FluidPropagator.getPipe(world, connectedPos);
		if (pipe != null && pipe.canHaveFlowToward(connectedState, blockFace.getOppositeFace()))
			return false;

		if (blockEntity != null) {
			if (blockEntity.getLevel()
				.getCapability(Capabilities.FluidHandler.BLOCK, blockEntity.getBlockPos(), face.getOpposite()) != null)
				return true;
		}

		return FluidPropagator.isOpenEnd(world, blockFace.getPos(), face);
	}

}
