package com.yision.fluidlogistics.registry;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.api.registry.CreateBuiltInRegistries;
import com.simibubi.create.content.kinetics.mechanicalArm.AllArmInteractionPointTypes;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPoint;
import com.simibubi.create.content.kinetics.mechanicalArm.ArmInteractionPointType;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock.HeatLevel;
import com.yision.fluidlogistics.FluidLogistics;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class FluidLogisticsArmInteractionPointTypes {

	public static final DeferredRegister<ArmInteractionPointType> ARM_INTERACTION_POINT_TYPES = DeferredRegister
		.create(CreateBuiltInRegistries.ARM_INTERACTION_POINT_TYPE.key(), FluidLogistics.MODID);

	public static final DeferredHolder<ArmInteractionPointType, ArmInteractionPointType> FLUID_PACKAGER = ARM_INTERACTION_POINT_TYPES
		.register("fluid_packager", FluidPackagerType::new);
	public static final DeferredHolder<ArmInteractionPointType, ArmInteractionPointType> SMART_HOPPER = ARM_INTERACTION_POINT_TYPES
		.register("smart_hopper", SmartHopperType::new);
	public static final DeferredHolder<ArmInteractionPointType, ArmInteractionPointType> SNOW_GOLEM_FREEZER = ARM_INTERACTION_POINT_TYPES
		.register("snow_golem_freezer", SnowGolemFreezerType::new);

	public static final DeferredHolder<ArmInteractionPointType, ArmInteractionPointType> COPPER_BASKET = ARM_INTERACTION_POINT_TYPES
		.register("copper_basket", () -> new ArmInteractionPointType() {
			@Override
			public boolean canCreatePoint(Level level, BlockPos pos, BlockState state) {
				return AllBlocks.COPPER_BASKET.has(state);
			}

			@Override
			public ArmInteractionPoint createPoint(Level level, BlockPos pos, BlockState state) {
				return new ArmInteractionPoint(this, level, pos, state);
			}
		});

	private static class FluidPackagerType extends ArmInteractionPointType {
		@Override
		public boolean canCreatePoint(Level level, BlockPos pos, BlockState state) {
			return AllBlocks.FLUID_PACKAGER.has(state) || AllBlocks.FLUID_REPACKAGER.has(state);
		}

		@Override
		public @Nullable ArmInteractionPoint createPoint(Level level, BlockPos pos, BlockState state) {
			return new ArmInteractionPoint(this, level, pos, state);
		}
	}

	private static class SmartHopperType extends ArmInteractionPointType {
		@Override
		public boolean canCreatePoint(Level level, BlockPos pos, BlockState state) {
			return AllBlocks.SMART_HOPPER.has(state);
		}

		@Override
		public @Nullable ArmInteractionPoint createPoint(Level level, BlockPos pos, BlockState state) {
			return new ArmInteractionPoint(this, level, pos, state);
		}
	}

	private static class SnowGolemFreezerType extends ArmInteractionPointType {
		@Override
		public boolean canCreatePoint(Level level, BlockPos pos, BlockState state) {
			return AllBlocks.SNOW_GOLEM_FREEZER.has(state)
				&& state.getValue(BlazeBurnerBlock.HEAT_LEVEL) != HeatLevel.NONE;
		}

		@Override
		public @Nullable ArmInteractionPoint createPoint(Level level, BlockPos pos, BlockState state) {
			return new AllArmInteractionPointTypes.BlazeBurnerPoint(this, level, pos, state);
		}
	}
}
