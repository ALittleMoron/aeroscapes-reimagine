package com.yision.fluidlogistics.content.processing.snowGolemFreezer;

import com.simibubi.create.api.behaviour.movement.MovementBehaviour;
import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.render.ContraptionMatrices;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock;
import com.simibubi.create.content.processing.burner.BlazeBurnerBlock.HeatLevel;
import com.simibubi.create.content.trains.entity.CarriageContraption;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.foundation.virtualWorld.VirtualRenderWorld;

import net.createmod.catnip.animation.LerpedFloat;
import net.createmod.catnip.animation.LerpedFloat.Chaser;
import net.createmod.catnip.data.Iterate;
import net.createmod.catnip.math.AngleHelper;
import net.createmod.catnip.math.VecHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.Direction;
import net.minecraft.core.Direction.Axis;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

public class SnowGolemFreezerMovementBehaviour implements MovementBehaviour {

	@Override
	public ItemStack canBeDisabledVia(MovementContext context) {
		return null;
	}

	@Override
	public void tick(MovementContext context) {
		if (!context.world.isClientSide() || BlazeBurnerBlock.getHeatLevelOf(context.state) == HeatLevel.NONE)
			return;

		if (context.position != null && context.motion.length() < 1 / 64f && context.world.random.nextInt(3) == 0) {
			Vec3 smoke = context.position.add(VecHelper.offsetRandomly(Vec3.ZERO, context.world.random, .125f)
				.multiply(1, 0, 1));
			SnowGolemFreezerParticles.spawnSmoke(context.world, smoke, false);
		}

		LerpedFloat headAngle = getHeadAngle(context);
		boolean quickTurn = shouldRenderHat(context) && !Mth.equal(context.relativeMotion.length(), 0);
		headAngle.chase(
			headAngle.getValue() + AngleHelper.getShortestAngleDiff(headAngle.getValue(), getTargetAngle(context)), .5f,
			quickTurn ? Chaser.EXP : Chaser.exp(5));
		headAngle.tickChaser();
	}

	public void invalidate(MovementContext context) {
		context.data.remove("Conductor");
	}

	private LerpedFloat getHeadAngle(MovementContext context) {
		if (!(context.temporaryData instanceof LerpedFloat))
			context.temporaryData = LerpedFloat.angular()
				.startWithValue(getTargetAngle(context));
		return (LerpedFloat) context.temporaryData;
	}

	private float getTargetAngle(MovementContext context) {
		if (shouldRenderHat(context) && !Mth.equal(context.relativeMotion.length(), 0)
			&& context.contraption.entity instanceof CarriageContraptionEntity carriageEntity) {
			float angle = AngleHelper.deg(-Mth.atan2(context.relativeMotion.x, context.relativeMotion.z));
			return carriageEntity.getInitialOrientation().getAxis() == Axis.X ? angle + 180 : angle;
		}

		Entity player = Minecraft.getInstance().cameraEntity;
		if (player != null && !player.isInvisible() && context.position != null) {
			Vec3 relativePlayerPosition = context.contraption.entity.reverseRotation(player.position()
				.subtract(context.position), 1);
			return AngleHelper.deg(-Mth.atan2(relativePlayerPosition.z, relativePlayerPosition.x)) - 90;
		}
		return 0;
	}

	private boolean shouldRenderHat(MovementContext context) {
		CompoundTag data = context.data;
		if (!data.contains("Conductor"))
			data.putBoolean("Conductor", determineIfConducting(context));
		return data.getBoolean("Conductor")
			&& context.contraption.entity instanceof CarriageContraptionEntity carriageEntity
			&& carriageEntity.hasSchedule();
	}

	private boolean determineIfConducting(MovementContext context) {
		Contraption contraption = context.contraption;
		if (!(contraption instanceof CarriageContraption carriageContraption))
			return false;
		Direction assemblyDirection = carriageContraption.getAssemblyDirection();
		for (Direction direction : Iterate.directionsInAxis(assemblyDirection.getAxis()))
			if (carriageContraption.inControl(context.localPos, direction))
				return true;
		return false;
	}

	@Override
	public boolean disableBlockEntityRendering() {
		return true;
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public void renderInContraption(MovementContext context, VirtualRenderWorld renderWorld,
		ContraptionMatrices matrices, MultiBufferSource bufferSource) {
		if (BlazeBurnerBlock.getHeatLevelOf(context.state) == HeatLevel.NONE)
			return;
		SnowGolemFreezerRenderer.renderInContraption(context, matrices, bufferSource, getHeadAngle(context),
			shouldRenderHat(context));
	}
}
