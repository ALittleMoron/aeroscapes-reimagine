/*
 * Copyright (C) 2025 DragonsPlus
 * SPDX-License-Identifier: LGPL-3.0-or-later
 *
 * Ported from CreateDragonsPlus to CreateFluidLogistics.
 */

package com.yision.fluidlogistics.content.fluids.itemTransfer;

import java.util.function.Predicate;

import com.simibubi.create.content.fluids.transfer.GenericItemFilling;

import net.minecraft.world.item.ItemStack;

import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.fluids.FluidStack;
import net.neoforged.neoforge.fluids.capability.IFluidHandler;
import net.neoforged.neoforge.fluids.capability.IFluidHandler.FluidAction;
import net.neoforged.neoforge.fluids.capability.IFluidHandlerItem;

public class ItemFluidCapabilityTransfer {
	public static TransferResult tryDrainItemToTank(ItemStack stack, IFluidHandler tankCapability,
		Predicate<FluidStack> filter) {
		return tryDrainItemToTank(stack, tankCapability, filter, FluidAction.EXECUTE);
	}

	static TransferResult tryDrainItemToTank(ItemStack stack, IFluidHandler tankCapability,
		Predicate<FluidStack> filter, FluidAction action) {
		IFluidHandlerItem itemCapability = getItemFluidHandler(stack, false);
		if (itemCapability == null)
			return TransferResult.EMPTY;

		for (int i = 0; i < itemCapability.getTanks(); i++) {
			FluidStack storedFluid = itemCapability.getFluidInTank(i);
			if (storedFluid.isEmpty() || !filter.test(storedFluid))
				continue;

			FluidStack fluidToMove = getDrainableFluid(itemCapability, tankCapability, storedFluid);
			if (fluidToMove.isEmpty())
				continue;

			FluidStack drainedFluid = itemCapability.drain(fluidToMove, FluidAction.EXECUTE);
			if (drainedFluid.isEmpty())
				continue;

			int filled = tankCapability.fill(drainedFluid.copy(), action);
			if (filled <= 0)
				continue;

			FluidStack movedFluid = drainedFluid.copy();
			movedFluid.setAmount(filled);
			stack.shrink(1);
			return new TransferResult(movedFluid, itemCapability.getContainer().copy());
		}
		return TransferResult.EMPTY;
	}

	public static TransferResult tryFillItemFromTank(ItemStack stack, IFluidHandler tankCapability,
		Predicate<FluidStack> filter) {
		return tryFillItemFromTank(stack, tankCapability, filter, FluidAction.EXECUTE);
	}

	static TransferResult tryFillItemFromTank(ItemStack stack, IFluidHandler tankCapability,
		Predicate<FluidStack> filter, FluidAction action) {
		IFluidHandlerItem itemCapability = getItemFluidHandler(stack, true);
		if (itemCapability == null)
			return TransferResult.EMPTY;

		for (int i = 0; i < tankCapability.getTanks(); i++) {
			FluidStack storedFluid = tankCapability.getFluidInTank(i);
			if (storedFluid.isEmpty() || !filter.test(storedFluid))
				continue;

			FluidStack fluidToMove = getFillableFluid(itemCapability, tankCapability, storedFluid);
			if (fluidToMove.isEmpty())
				continue;

			int filled = itemCapability.fill(fluidToMove.copy(), FluidAction.EXECUTE);
			if (filled <= 0)
				continue;

			FluidStack movedFluid = fluidToMove.copy();
			movedFluid.setAmount(filled);
			FluidStack drainedFluid = tankCapability.drain(movedFluid.copy(), action);
			if (drainedFluid.isEmpty())
				continue;

			movedFluid.setAmount(drainedFluid.getAmount());
			stack.shrink(1);
			return new TransferResult(movedFluid, itemCapability.getContainer().copy());
		}
		return TransferResult.EMPTY;
	}

	public static boolean canItemBeFilled(ItemStack stack) {
		IFluidHandlerItem itemCapability = getItemFluidHandler(stack, true);
		if (itemCapability == null)
			return false;
		for (int i = 0; i < itemCapability.getTanks(); i++) {
			if (itemCapability.getFluidInTank(i).getAmount() < itemCapability.getTankCapacity(i))
				return true;
		}
		return false;
	}

	public static boolean canItemBeEmptied(ItemStack stack) {
		IFluidHandlerItem itemCapability = getItemFluidHandler(stack, false);
		if (itemCapability == null)
			return false;
		for (int i = 0; i < itemCapability.getTanks(); i++) {
			if (!itemCapability.getFluidInTank(i).isEmpty())
				return true;
		}
		return false;
	}

	private static FluidStack getDrainableFluid(
		IFluidHandlerItem itemCapability, IFluidHandler tankCapability, FluidStack storedFluid) {
		FluidStack availableFluid = storedFluid.copy();
		int acceptableAmount = tankCapability.fill(availableFluid, FluidAction.SIMULATE);
		if (acceptableAmount <= 0)
			return FluidStack.EMPTY;

		FluidStack requestedFluid = storedFluid.copy();
		requestedFluid.setAmount(acceptableAmount);
		FluidStack drainableFluid = itemCapability.drain(requestedFluid, FluidAction.SIMULATE);
		if (drainableFluid.isEmpty())
			return FluidStack.EMPTY;

		int realAcceptableAmount = tankCapability.fill(drainableFluid.copy(), FluidAction.SIMULATE);
		if (realAcceptableAmount <= 0)
			return FluidStack.EMPTY;
		if (realAcceptableAmount < drainableFluid.getAmount())
			drainableFluid.setAmount(realAcceptableAmount);
		return drainableFluid;
	}

	private static FluidStack getFillableFluid(
		IFluidHandlerItem itemCapability, IFluidHandler tankCapability, FluidStack storedFluid) {
		FluidStack availableFluid = storedFluid.copy();
		int fillableAmount = itemCapability.fill(availableFluid, FluidAction.SIMULATE);
		if (fillableAmount <= 0)
			return FluidStack.EMPTY;

		FluidStack requestedFluid = storedFluid.copy();
		requestedFluid.setAmount(fillableAmount);
		FluidStack drainableFluid = tankCapability.drain(requestedFluid, FluidAction.SIMULATE);
		if (drainableFluid.isEmpty())
			return FluidStack.EMPTY;

		int realFillableAmount = itemCapability.fill(drainableFluid.copy(), FluidAction.SIMULATE);
		if (realFillableAmount <= 0)
			return FluidStack.EMPTY;
		if (realFillableAmount < drainableFluid.getAmount())
			drainableFluid.setAmount(realFillableAmount);
		return drainableFluid;
	}

	private static IFluidHandlerItem getItemFluidHandler(ItemStack stack, boolean forFilling) {
		ItemStack split = stack.copy();
		split.setCount(1);
		IFluidHandlerItem itemCapability = split.getCapability(Capabilities.FluidHandler.ITEM);
		if (itemCapability == null)
			return null;
		if (forFilling && !GenericItemFilling.isFluidHandlerValid(split, itemCapability))
			return null;
		return itemCapability;
	}

	public record TransferResult(FluidStack fluidStack, ItemStack result) {
		public static final TransferResult EMPTY = new TransferResult(FluidStack.EMPTY, ItemStack.EMPTY);

		public boolean isEmpty() {
			return fluidStack.isEmpty();
		}
	}
}
