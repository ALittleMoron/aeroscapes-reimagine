package xerca.xercamusic.common.packets.serverbound;

import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import xerca.xercamusic.common.MusicManager;
import xerca.xercamusic.common.NoteEvent;
import xerca.xercamusic.common.Triggers;
import xerca.xercamusic.common.VolumeMarker;
import xerca.xercamusic.common.item.ItemMusicSheet;
import xerca.xercamusic.common.item.Items;

import java.util.List;
import java.util.UUID;

public final class MusicUpdatePacketHandler {
    private static byte sanitizeBps(byte bps) {
        return (byte) Math.clamp(bps & 0xFF, 1, 50);
    }

    private static float sanitizeVolume(float volume) {
        return Math.clamp(volume, 0.0f, 1.0f);
    }

    private static byte sanitizeHighlightInterval(byte interval) {
        return (byte) Math.clamp(interval & 0xFF, 1, 24);
    }

    private static void processMessage(MusicUpdatePacket msg, ServerPlayer pl) {
        ItemStack note = pl.getMainHandItem();
        if (!note.isEmpty() && note.getItem() == Items.MUSIC_SHEET) {
            MusicUpdatePacket.FieldFlag flag = msg.availability();
            if (flag.hasId) {
                UUID id = msg.id();
                if (id == null) {
                    return;
                }
                note.set(Items.SHEET_ID, id);
            }
            if (flag.hasVersion) note.set(Items.SHEET_VERSION, msg.version());
            if (flag.hasLength) note.set(Items.SHEET_LENGTH, (int) msg.lengthBeats());
            if (flag.hasBps) note.set(Items.SHEET_BPS, sanitizeBps(msg.bps()));
            if (flag.hasVolume) note.set(Items.SHEET_VOLUME, sanitizeVolume(msg.volume()));
            if (flag.hasPrevIns) note.set(Items.SHEET_PREV_INSTRUMENT, msg.prevInstrument());
            if (flag.hasPrevInsLocked) note.set(Items.SHEET_PREV_INSTRUMENT_LOCKED, msg.prevInsLocked());
            if (flag.hasHlInterval) note.set(Items.SHEET_HIGHLIGHT_INTERVAL, sanitizeHighlightInterval(msg.highlightInterval()));
            if (flag.hasSigned && msg.signed()) {
                String title = msg.title();
                if (!flag.hasTitle || title == null) {
                    return;
                }
                note.set(Items.SHEET_TITLE, title.trim());
                note.set(Items.SHEET_AUTHOR, pl.getName().getString());
                note.set(Items.SHEET_GENERATION, 1);
                ItemMusicSheet.updateStackSize(note);
                Triggers.BECOME_MUSICIAN.trigger(pl);
            }
            if (flag.hasNotes) {
                List<NoteEvent> notes = msg.notes();
                UUID id = note.get(Items.SHEET_ID);
                if (id == null) {
                    return;
                }
                if (notes == null) {
                    // Get if a large sheet was sent in parts
                    notes = MusicManager.getFinishedNotesFromBuffer(id);
                    if (notes.isEmpty()) {
                        return;
                    }
                }
                List<VolumeMarker> volumeMarkers = flag.hasVolumeMarkers ? msg.volumeMarkers() : null;
                MusicManager.setMusicData(id, note.getOrDefault(Items.SHEET_VERSION, 0), notes, volumeMarkers, pl.server);
                if (note.get(Items.SHEET_BPS) == null) {
                    note.set(Items.SHEET_BPS, (byte) 8);
                }
            }
        }
    }

    public static void handle(MusicUpdatePacket packet, IPayloadContext context) {
        context.enqueueWork(() -> processMessage(packet, (ServerPlayer) context.player()));
    }
}
