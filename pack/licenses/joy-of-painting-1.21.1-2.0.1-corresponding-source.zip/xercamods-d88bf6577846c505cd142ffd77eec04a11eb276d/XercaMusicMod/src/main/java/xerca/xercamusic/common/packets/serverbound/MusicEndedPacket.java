package xerca.xercamusic.common.packets.serverbound;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import xerca.xercamusic.common.Mod;


public record MusicEndedPacket(int playerId) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<MusicEndedPacket> PACKET_ID = new CustomPacketPayload.Type<>(Mod.id("music_ended"));
    public static final StreamCodec<FriendlyByteBuf, MusicEndedPacket> PACKET_CODEC = StreamCodec.ofMember(MusicEndedPacket::encode, MusicEndedPacket::decode);

    public static MusicEndedPacket decode(FriendlyByteBuf buf) {
        int playerId = buf.readInt();
        return new MusicEndedPacket(playerId);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(playerId);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return PACKET_ID;
    }
}
