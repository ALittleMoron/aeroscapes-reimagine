package xerca.xercamusic.common.packets.serverbound;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import xerca.xercamusic.common.Mod;

import java.util.UUID;

public record MusicDataRequestPacket(UUID id, int version) implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<MusicDataRequestPacket> PACKET_ID = new CustomPacketPayload.Type<>(Mod.id("music_data_request"));
    public static final StreamCodec<FriendlyByteBuf, MusicDataRequestPacket> PACKET_CODEC = StreamCodec.ofMember(MusicDataRequestPacket::encode, MusicDataRequestPacket::decode);

    public static MusicDataRequestPacket decode(FriendlyByteBuf buf) {
        UUID id = buf.readUUID();
        int version = buf.readInt();
        return new MusicDataRequestPacket(id, version);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUUID(id());
        buf.writeInt(version());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return PACKET_ID;
    }
}
