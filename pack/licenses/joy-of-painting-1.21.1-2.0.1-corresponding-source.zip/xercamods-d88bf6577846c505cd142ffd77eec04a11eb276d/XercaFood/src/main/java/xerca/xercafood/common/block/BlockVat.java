package xerca.xercafood.common.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public class BlockVat extends Block {
    public enum VatContent {EMPTY, MILK, CHEESE}

    private static final VoxelShape INSIDE = box(1.0D, 7.0D, 1.0D, 15.0D, 16.0D, 15.0D);
    private static final VoxelShape SHAPE = Shapes.join(Shapes.block(), Shapes.or(
            box(0.0D, 0.0D, 4.0D, 16.0D, 6.0D, 12.0D),
            box(4.0D, 0.0D, 0.0D, 12.0D, 6.0D, 16.0D),
            box(1.0D, 0.0D, 1.0D, 15.0D, 6.0D, 15.0D),
            INSIDE), BooleanOp.ONLY_FIRST);


    private final VatContent content;

    public BlockVat(VatContent content) {
        super(BlockBehaviour.Properties.of().strength(1.5F).noOcclusion().randomTicks());
        this.content = content;
    }

    @Override
    public VoxelShape getShape(BlockState blockState, BlockGetter blockGetter, BlockPos blockPos, CollisionContext collisionContext) {
        return SHAPE;
    }

    @Override
    public VoxelShape getInteractionShape(BlockState blockState, BlockGetter blockGetter, BlockPos blockPos) {
        return INSIDE;
    }


    @Override
    public ItemInteractionResult useItemOn(ItemStack itemstack, BlockState blockState, Level level, BlockPos blockPos, Player player, InteractionHand hand, BlockHitResult blockHitResult) {
        if (content == VatContent.EMPTY && itemstack.getItem() == Items.MILK_BUCKET) {
            if (!player.isCreative()) {
                itemstack.shrink(1);
                player.addItem(new ItemStack(Items.BUCKET));
            }

            level.setBlockAndUpdate(blockPos, Blocks.VAT_MILK.defaultBlockState());
            level.playSound(null, blockPos, SoundEvents.BOTTLE_EMPTY, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.gameEvent(null, GameEvent.FLUID_PLACE, blockPos);
            return ItemInteractionResult.SUCCESS;
        }
        if (content == VatContent.MILK && itemstack.getItem() == Items.BUCKET) {
            if (!player.isCreative()) {
                itemstack.shrink(1);
                player.addItem(new ItemStack(Items.MILK_BUCKET));
            }

            level.setBlockAndUpdate(blockPos, Blocks.VAT.defaultBlockState());
            level.playSound(null, blockPos, SoundEvents.BUCKET_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.gameEvent(null, GameEvent.FLUID_PICKUP, blockPos);
            return ItemInteractionResult.SUCCESS;
        }
        if (content == VatContent.CHEESE) {
            InteractionResult used = useWithoutItem(blockState, level, blockPos, player, blockHitResult);
            return used.consumesAction() ? ItemInteractionResult.SUCCESS : ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    public InteractionResult useWithoutItem(BlockState blockState, Level level, BlockPos blockPos, Player player, BlockHitResult blockHitResult) {
        if (content != VatContent.CHEESE) {
            return InteractionResult.PASS;
        }
        if (!level.isClientSide) {
            Vec3 playerPos = new Vec3(player.getX(), player.getY(), player.getZ());
            Vec3 boost = playerPos.subtract(new Vec3(blockPos.getX(), blockPos.getY() + 1.0, blockPos.getZ()));
            boost = boost.normalize().scale(0.15);

            ItemEntity entity = new ItemEntity(level, blockPos.getX(), blockPos.getY() + 1.0, blockPos.getZ(),
                    new ItemStack(xerca.xercafood.common.item.Items.CHEESE_WHEEL));
            entity.setDefaultPickUpDelay();
            entity.push(boost.x, 0.05, boost.z);
            entity.hurtMarked = true;
            level.addFreshEntity(entity);
            level.setBlockAndUpdate(blockPos, Blocks.VAT.defaultBlockState());
            level.playSound(null, blockPos, SoundEvents.SLIME_BLOCK_BREAK, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.gameEvent(null, GameEvent.FLUID_PICKUP, blockPos);
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public void randomTick(BlockState blockState, ServerLevel level, BlockPos blockPos, RandomSource random) {
        if (content == VatContent.MILK) {
            level.setBlockAndUpdate(blockPos, Blocks.VAT_CHEESE.defaultBlockState());
            level.playSound(null, blockPos, SoundEvents.SLIME_BLOCK_STEP, SoundSource.BLOCKS, 0.7F, 0.9F + level.random.nextFloat() * 0.2f);
        }
    }
}
