package xerca.xercafood.common.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Block;
import xerca.xercafood.common.Mod;
import xerca.xercafood.common.block.BlockPizza;

import java.util.List;

public class ItemPizza extends BlockItem {
    private final BlockPizza.Ingredient slot1;
    private final BlockPizza.Ingredient slot2;
    private final BlockPizza.Ingredient slot3;

    public ItemPizza(Block blockIn, BlockPizza.Ingredient slot1, BlockPizza.Ingredient slot2, BlockPizza.Ingredient slot3) {
        super(blockIn, new Item.Properties());
        this.slot1 = slot1;
        this.slot2 = slot2;
        this.slot3 = slot3;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flagIn) {
        addPizzaIngredientToTooltip(tooltip, slot1);
        addPizzaIngredientToTooltip(tooltip, slot2);
        addPizzaIngredientToTooltip(tooltip, slot3);
    }

    static void addPizzaIngredientToTooltip(List<Component> tooltip, BlockPizza.Ingredient ingredient) {
        if (ingredient != BlockPizza.Ingredient.EMPTY) {
            tooltip.add(Component.translatable(Mod.MOD_ID + ".ingredient." + ingredient.name().toLowerCase()).withStyle(ChatFormatting.GRAY));
        }
    }

    @Override
    public Component getName(ItemStack stack) {
        if (slot1 == BlockPizza.Ingredient.EMPTY && slot2 == BlockPizza.Ingredient.EMPTY && slot3 == BlockPizza.Ingredient.EMPTY)
            return Component.translatable(Mod.MOD_ID + ".pizza_plain");
        return Component.translatable(Mod.MOD_ID + ".pizza");
    }
}
