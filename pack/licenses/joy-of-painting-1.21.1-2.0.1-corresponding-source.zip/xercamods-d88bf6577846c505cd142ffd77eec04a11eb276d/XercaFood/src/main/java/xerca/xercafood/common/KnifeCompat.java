package xerca.xercafood.common;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.fml.ModList;
import xerca.xercafood.common.item.Items;

public final class KnifeCompat {
    private static final ResourceLocation XERCATOOLS_KNIFE_ID = ResourceLocation.fromNamespaceAndPath("xercatools", "knife");
    private static final TagKey<Item> KNIFE_TAG = TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath("c", "tools/knife"));

    private KnifeCompat() {
    }

    public static boolean useToolsKnife() {
        return ModList.get().isLoaded("xercatools") && BuiltInRegistries.ITEM.containsKey(XERCATOOLS_KNIFE_ID);
    }

    public static Item getKnifeItem() {
        if (useToolsKnife()) {
            return BuiltInRegistries.ITEM.get(XERCATOOLS_KNIFE_ID);
        }
        return Items.requireLocalKnife();
    }

    public static boolean isKnife(ItemStack stack) {
        return !stack.isEmpty() && stack.is(KNIFE_TAG);
    }
}
