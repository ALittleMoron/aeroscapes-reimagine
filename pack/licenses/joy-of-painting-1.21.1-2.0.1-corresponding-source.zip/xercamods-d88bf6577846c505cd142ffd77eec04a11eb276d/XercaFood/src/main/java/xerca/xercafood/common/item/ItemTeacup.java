package xerca.xercafood.common.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import org.lwjgl.system.NonnullDefault;

import java.util.List;

@NonnullDefault
public class ItemTeacup extends ItemStackableContainedFood {
    private final int sugarAmount;

    public ItemTeacup(int sugarAmount, Item teaCup) {
        super(createProperties(sugarAmount), teaCup, 64);
        this.sugarAmount = sugarAmount;
    }

    private static Item.Properties createProperties(int sugarAmount) {
        return switch (sugarAmount) {
            case 0 -> new Item.Properties().food(Foods.TEACUP0);
            case 1 -> new Item.Properties().food(Foods.TEACUP1);
            case 2 -> new Item.Properties().food(Foods.TEACUP2);
            case 3 -> new Item.Properties().food(Foods.TEACUP3);
            case 4 -> new Item.Properties().food(Foods.TEACUP4);
            case 5 -> new Item.Properties().food(Foods.TEACUP5);
            default -> new Item.Properties().food(Foods.TEACUP6);
        };
    }

    @Override
    public UseAnim getUseAnimation(ItemStack par1ItemStack) {
        return UseAnim.DRINK;
    }

    public int getSugarAmount() {
        return sugarAmount;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flagIn) {
        if (this.sugarAmount == 0) {
            tooltip.add(Component.literal("No sugar"));
        } else if (this.sugarAmount == 1) {
            tooltip.add(Component.literal(this.sugarAmount + " sugar"));
        } else {
            tooltip.add(Component.literal(this.sugarAmount + " sugars"));
        }
    }

    @Override
    public boolean isBarVisible(ItemStack stack) {
        return false;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 64;
    }
}
