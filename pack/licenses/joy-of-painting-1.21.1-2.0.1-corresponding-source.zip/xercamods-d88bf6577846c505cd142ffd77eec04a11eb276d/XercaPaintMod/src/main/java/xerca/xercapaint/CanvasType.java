package xerca.xercapaint;


public enum CanvasType {
    SMALL, LARGE, LONG, TALL;

    public byte toByte() {
        return switch (this) {
            case SMALL -> 0;
            case LARGE -> 1;
            case LONG -> 2;
            case TALL -> 3;
        };
    }

    public static CanvasType fromByte(byte x) {
        return switch (x) {
            case 1 -> LARGE;
            case 2 -> LONG;
            case 3 -> TALL;
            default -> SMALL;
        };
    }

    public static int getWidth(CanvasType canvasType) {
        return switch (canvasType) {
            case SMALL, TALL -> 16;
            case LARGE, LONG -> 32;
        };
    }

    public static int getHeight(CanvasType canvasType) {
        return switch (canvasType) {
            case SMALL, LONG -> 16;
            case LARGE, TALL -> 32;
        };
    }
}
