package xerca.xercaomnichest.tests;

import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CraftingRecipe;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;
import xerca.xercaomnichest.Mod;
import xerca.xercaomnichest.block.BlockOmniChest;
import xerca.xercaomnichest.block.Blocks;
import xerca.xercaomnichest.block_entity.BlockEntityOmniChest;
import xerca.xercaomnichest.data.OmniChestInventory;
import xerca.xercaomnichest.data.OmniChestSavedData;
import xerca.xercaomnichest.item.Items;

import java.util.List;
import java.util.Optional;

@GameTestHolder(Mod.MOD_ID)
@PrefixGameTestTemplate(false)
public final class OmniChestGameTests {
    private static final String BASIC_TEMPLATE = "basic_test";
    private static final String BATCH = "xercaomnichest.omni_chest";

    private static ResourceLocation recipeId(String path) {
        return Mod.id(path);
    }

    private static CraftingRecipe requireCraftingRecipe(GameTestHelper helper, ResourceLocation recipeId) {
        Optional<RecipeHolder<?>> recipeOptional = helper.getLevel().getRecipeManager().byKey(recipeId);
        helper.assertTrue(recipeOptional.isPresent(), "Missing recipe: " + recipeId);
        Recipe<?> recipe = recipeOptional.orElseThrow().value();
        helper.assertTrue(recipe instanceof CraftingRecipe, "Expected crafting recipe for " + recipeId);
        assert recipe instanceof CraftingRecipe;
        return (CraftingRecipe) recipe;
    }

    private static BlockEntityOmniChest requireOmniChest(GameTestHelper helper, BlockPos pos, String message) {
        if (helper.getLevel().getBlockEntity(pos) instanceof BlockEntityOmniChest chest) {
            return chest;
        }
        helper.assertTrue(false, message);
        throw new IllegalStateException("Unreachable after GameTest assertion failure");
    }

    private static BlockHitResult hitTopOf(BlockPos pos) {
        return new BlockHitResult(Vec3.atCenterOf(pos), net.minecraft.core.Direction.UP, pos, false);
    }

    private static InteractionResult invokeUseWithoutItem(GameTestHelper helper, BlockPos pos, Player player) {
        BlockState state = helper.getLevel().getBlockState(pos);
        try {
            java.lang.reflect.Method method = net.minecraft.world.level.block.state.BlockBehaviour.class.getDeclaredMethod(
                    "useWithoutItem",
                    BlockState.class,
                    net.minecraft.world.level.Level.class,
                    BlockPos.class,
                    Player.class,
                    BlockHitResult.class
            );
            method.setAccessible(true);
            return (InteractionResult) method.invoke(state.getBlock(), state, helper.getLevel(), pos, player, hitTopOf(pos));
        } catch (Exception e) {
            helper.fail("Failed to invoke Omni Chest useWithoutItem: " + e.getMessage());
            return InteractionResult.FAIL;
        }
    }

    private static ItemInteractionResult invokeUseItemOn(GameTestHelper helper, BlockPos pos, Player player, ItemStack stack) {
        BlockState state = helper.getLevel().getBlockState(pos);
        try {
            java.lang.reflect.Method method = net.minecraft.world.level.block.state.BlockBehaviour.class.getDeclaredMethod(
                    "useItemOn",
                    ItemStack.class,
                    BlockState.class,
                    net.minecraft.world.level.Level.class,
                    BlockPos.class,
                    Player.class,
                    InteractionHand.class,
                    BlockHitResult.class
            );
            method.setAccessible(true);
            return (ItemInteractionResult) method.invoke(state.getBlock(), stack, state, helper.getLevel(), pos, player, InteractionHand.MAIN_HAND, hitTopOf(pos));
        } catch (Exception e) {
            helper.fail("Failed to invoke Omni Chest useItemOn: " + e.getMessage());
            return ItemInteractionResult.FAIL;
        }
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestRecipeCraftsFromAmethystEyesAndEnderChest(GameTestHelper helper) {
        CraftingRecipe recipe = requireCraftingRecipe(helper, recipeId("omni_chest"));
        CraftingInput grid = CraftingInput.of(3, 3, java.util.List.of(
                new ItemStack(net.minecraft.world.item.Items.AMETHYST_BLOCK), new ItemStack(net.minecraft.world.item.Items.ENDER_EYE), new ItemStack(net.minecraft.world.item.Items.AMETHYST_BLOCK),
                new ItemStack(net.minecraft.world.item.Items.ENDER_EYE), new ItemStack(net.minecraft.world.item.Items.ENDER_CHEST), new ItemStack(net.minecraft.world.item.Items.ENDER_EYE),
                new ItemStack(net.minecraft.world.item.Items.AMETHYST_BLOCK), new ItemStack(net.minecraft.world.item.Items.ENDER_EYE), new ItemStack(net.minecraft.world.item.Items.AMETHYST_BLOCK)
        ));

        helper.assertTrue(recipe.matches(grid, helper.getLevel()), "Expected Omni Chest recipe to match");
        ItemStack result = recipe.assemble(grid, helper.getLevel().registryAccess());
        helper.assertTrue(result.is(Items.OMNI_CHEST), "Expected recipe to craft Omni Chest");
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestInventoryIsSharedAcrossPlacedChests(GameTestHelper helper) {
        BlockPos firstPos = helper.absolutePos(new BlockPos(1, 2, 1));
        BlockPos secondPos = helper.absolutePos(new BlockPos(3, 2, 1));
        helper.getLevel().setBlockAndUpdate(firstPos, Blocks.OMNI_CHEST.defaultBlockState());
        helper.getLevel().setBlockAndUpdate(secondPos, Blocks.OMNI_CHEST.defaultBlockState());

        OmniChestInventory inventory = BlockOmniChest.getContainer(helper.getLevel().getServer());
        inventory.setItem(0, new ItemStack(net.minecraft.world.item.Items.DIAMOND, 7));

        Player firstPlayer = helper.makeMockPlayer(GameType.SURVIVAL);
        Player secondPlayer = helper.makeMockPlayer(GameType.SURVIVAL);

        BlockEntityOmniChest firstChest = requireOmniChest(helper, firstPos, "Expected first Omni Chest block entity");
        BlockEntityOmniChest secondChest = requireOmniChest(helper, secondPos, "Expected second Omni Chest block entity");

        inventory.setActiveChest(firstChest, firstPlayer);
        inventory.setActiveChest(secondChest, secondPlayer);

        ChestMenu firstMenu = ChestMenu.threeRows(0, firstPlayer.getInventory(), inventory);
        ChestMenu secondMenu = ChestMenu.threeRows(1, secondPlayer.getInventory(), inventory);

        helper.assertTrue(firstMenu.getContainer().getItem(0).getCount() == 7, "Expected first player to see shared inventory contents");
        helper.assertTrue(secondMenu.getContainer().getItem(0).getCount() == 7, "Expected second player to see shared inventory contents");

        secondMenu.getContainer().setItem(0, new ItemStack(net.minecraft.world.item.Items.EMERALD, 3));
        helper.assertTrue(firstMenu.getContainer().getItem(0).is(net.minecraft.world.item.Items.EMERALD), "Expected inventory mutation to be shared");
        helper.assertTrue(firstMenu.getContainer().getItem(0).getCount() == 3, "Expected shared inventory count to update");

        secondMenu.removed(secondPlayer);
        firstMenu.removed(firstPlayer);
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestTracksDifferentActiveChestsPerPlayer(GameTestHelper helper) {
        BlockPos firstPos = helper.absolutePos(new BlockPos(1, 2, 1));
        BlockPos secondPos = helper.absolutePos(new BlockPos(3, 2, 1));
        helper.getLevel().setBlockAndUpdate(firstPos, Blocks.OMNI_CHEST.defaultBlockState());
        helper.getLevel().setBlockAndUpdate(secondPos, Blocks.OMNI_CHEST.defaultBlockState());

        Player firstPlayer = helper.makeMockPlayer(GameType.SURVIVAL);
        Player secondPlayer = helper.makeMockPlayer(GameType.SURVIVAL);
        OmniChestInventory inventory = BlockOmniChest.getContainer(helper.getLevel().getServer());

        BlockEntityOmniChest firstChest = requireOmniChest(helper, firstPos, "Expected first Omni Chest block entity");
        BlockEntityOmniChest secondChest = requireOmniChest(helper, secondPos, "Expected second Omni Chest block entity");
        inventory.setActiveChest(firstChest, firstPlayer);
        inventory.setActiveChest(secondChest, secondPlayer);

        helper.assertTrue(inventory.testPlayerChest(firstPlayer, firstChest), "Expected first player to be tracked against first chest");
        helper.assertTrue(inventory.testPlayerChest(secondPlayer, secondChest), "Expected second player to be tracked against second chest");
        helper.assertTrue(!inventory.testPlayerChest(firstPlayer, secondChest), "Expected players to keep separate active chest mappings");
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestSavedDataRoundTripsStoredItems(GameTestHelper helper) {
        OmniChestSavedData original = new OmniChestSavedData();
        original.getInventory().setItem(4, new ItemStack(net.minecraft.world.item.Items.DIAMOND, 5));

        CompoundTag tag = original.save(new CompoundTag(), helper.getLevel().registryAccess());
        OmniChestSavedData restored = OmniChestSavedData.load(tag, helper.getLevel().registryAccess());

        ItemStack restoredStack = restored.getInventory().getItem(4);
        helper.assertTrue(restoredStack.is(net.minecraft.world.item.Items.DIAMOND), "Expected saved data to restore the stored item");
        helper.assertTrue(restoredStack.getCount() == 5, "Expected saved data to restore the stored item count");
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestBreaksAtPickaxeSpeedLikeEnderChest(GameTestHelper helper) {
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        helper.getLevel().setBlockAndUpdate(pos, Blocks.OMNI_CHEST.defaultBlockState());

        Player player = helper.makeMockPlayer(GameType.SURVIVAL);
        BlockState omniChestState = helper.getLevel().getBlockState(pos);
        BlockState enderChestState = net.minecraft.world.level.block.Blocks.ENDER_CHEST.defaultBlockState();

        player.getInventory().setItem(player.getInventory().selected, ItemStack.EMPTY);
        float handProgress = omniChestState.getDestroyProgress(player, helper.getLevel(), pos);

        ItemStack pickaxe = new ItemStack(net.minecraft.world.item.Items.NETHERITE_PICKAXE);
        EnchantmentHelper.updateEnchantments(pickaxe, enchantments -> enchantments.set(
                helper.getLevel().registryAccess()
                        .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                        .getOrThrow(net.minecraft.world.item.enchantment.Enchantments.EFFICIENCY),
                5
        ));
        player.getInventory().setItem(player.getInventory().selected, pickaxe);

        float omniChestProgress = omniChestState.getDestroyProgress(player, helper.getLevel(), pos);
        float enderChestProgress = enderChestState.getDestroyProgress(player, helper.getLevel(), pos);

        helper.assertTrue(omniChestProgress > handProgress, "Expected pickaxe mining progress to be faster than hand mining progress");
        helper.assertTrue(Math.abs(omniChestProgress - enderChestProgress) < 0.000001F, "Expected Omni Chest mining progress to match Ender Chest with the same pickaxe");
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestLootRequiresSilkTouchForFullBlockDrop(GameTestHelper helper) {
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        helper.getLevel().setBlockAndUpdate(pos, Blocks.OMNI_CHEST.defaultBlockState());
        BlockState state = helper.getLevel().getBlockState(pos);
        BlockEntity blockEntity = helper.getLevel().getBlockEntity(pos);

        List<ItemStack> normalDrops = net.minecraft.world.level.block.Block.getDrops(
                state,
                helper.getLevel(),
                pos,
                blockEntity,
                null,
                new ItemStack(net.minecraft.world.item.Items.NETHERITE_PICKAXE)
        );
        helper.assertTrue(normalDrops.size() == 1, "Expected one non-silk-touch drop");
        helper.assertTrue(normalDrops.getFirst().is(net.minecraft.world.item.Items.OBSIDIAN), "Expected non-silk-touch Omni Chest to drop obsidian");
        helper.assertTrue(normalDrops.getFirst().getCount() == 8, "Expected non-silk-touch Omni Chest to drop eight obsidian");

        ItemStack silkTouchPickaxe = new ItemStack(net.minecraft.world.item.Items.NETHERITE_PICKAXE);
        EnchantmentHelper.updateEnchantments(silkTouchPickaxe, enchantments -> enchantments.set(
                helper.getLevel().registryAccess()
                        .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT)
                        .getOrThrow(net.minecraft.world.item.enchantment.Enchantments.SILK_TOUCH),
                1
        ));

        List<ItemStack> silkTouchDrops = net.minecraft.world.level.block.Block.getDrops(
                state,
                helper.getLevel(),
                pos,
                blockEntity,
                null,
                silkTouchPickaxe
        );
        helper.assertTrue(silkTouchDrops.size() == 1, "Expected one silk-touch drop");
        helper.assertTrue(silkTouchDrops.getFirst().is(Items.OMNI_CHEST), "Expected silk-touch Omni Chest to drop itself");
        helper.assertTrue(silkTouchDrops.getFirst().getCount() == 1, "Expected silk-touch Omni Chest to drop exactly one block");
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestCanBePlacedWaterlogged(GameTestHelper helper) {
        BlockPos supportPos = helper.absolutePos(new BlockPos(1, 1, 1));
        BlockPos chestPos = supportPos.above();
        helper.getLevel().setBlockAndUpdate(supportPos, net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());
        helper.getLevel().setBlockAndUpdate(chestPos, net.minecraft.world.level.block.Blocks.WATER.defaultBlockState());

        Player player = helper.makeMockPlayer(GameType.SURVIVAL);
        ItemStack chestStack = new ItemStack(Items.OMNI_CHEST);
        player.setItemInHand(InteractionHand.MAIN_HAND, chestStack);
        Items.OMNI_CHEST.useOn(new UseOnContext(player, InteractionHand.MAIN_HAND, hitTopOf(supportPos)));

        BlockState placedState = helper.getLevel().getBlockState(chestPos);
        helper.assertTrue(placedState.is(Blocks.OMNI_CHEST), "Expected Omni Chest item placement to replace the water block");
        helper.assertTrue(placedState.getValue(BlockOmniChest.WATERLOGGED), "Expected placed Omni Chest to keep waterlogged state");
        helper.assertTrue(helper.getLevel().getFluidState(chestPos).getType() == Fluids.WATER, "Expected waterlogged Omni Chest to expose a water fluid state");
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void omniChestUseItemOpensMenuAndTracksActiveChest(GameTestHelper helper) {
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        helper.getLevel().setBlockAndUpdate(pos, Blocks.OMNI_CHEST.defaultBlockState());

        Player player = helper.makeMockPlayer(GameType.SURVIVAL);
        BlockEntityOmniChest chest = requireOmniChest(helper, pos, "Expected Omni Chest block entity");
        OmniChestInventory inventory = BlockOmniChest.getContainer(helper.getLevel().getServer());

        ItemInteractionResult result = invokeUseItemOn(helper, pos, player, ItemStack.EMPTY);

        helper.assertTrue(result == ItemInteractionResult.SUCCESS, "Expected item interaction to open the Omni Chest");
        helper.assertTrue(inventory.testPlayerChest(player, chest), "Expected Omni Chest interaction to track the player's active chest");
        helper.succeed();
    }

    @GameTest(template = BASIC_TEMPLATE, batch = BATCH)
    public static void blockedOmniChestDoesNotOpenMenu(GameTestHelper helper) {
        BlockPos pos = helper.absolutePos(new BlockPos(1, 2, 1));
        helper.getLevel().setBlockAndUpdate(pos, Blocks.OMNI_CHEST.defaultBlockState());
        helper.getLevel().setBlockAndUpdate(pos.above(), net.minecraft.world.level.block.Blocks.STONE.defaultBlockState());

        Player player = helper.makeMockPlayer(GameType.SURVIVAL);
        BlockEntityOmniChest chest = requireOmniChest(helper, pos, "Expected Omni Chest block entity");
        OmniChestInventory inventory = BlockOmniChest.getContainer(helper.getLevel().getServer());

        InteractionResult result = invokeUseWithoutItem(helper, pos, player);

        helper.assertTrue(result == InteractionResult.PASS, "Expected blocked Omni Chest to refuse menu opening");
        helper.assertFalse(inventory.testPlayerChest(player, chest), "Expected blocked Omni Chest not to register an active chest for the player");
        helper.assertFalse(player.containerMenu instanceof ChestMenu, "Expected blocked Omni Chest not to open a chest menu");
        helper.succeed();
    }
}
